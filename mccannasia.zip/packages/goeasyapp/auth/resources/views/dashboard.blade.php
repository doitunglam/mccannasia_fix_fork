@extends('component::components.layout.default')
@section('content')
<div class="col-12">
<h1>ádsadsd</h1>
    <x-component::input.ckeditor name="aaaa" value=""/>
</div>
@endsection()

@section('script')
@stack('c-script')
@endsection()