<?php

return [
    'required'=>'This field is required dog dog dog'
];