<?php

return [
    'required'=>'Trường này ko được để trống'
];