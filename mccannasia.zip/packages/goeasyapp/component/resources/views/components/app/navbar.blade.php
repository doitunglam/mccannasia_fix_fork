<a href="{{route('home')}}" class="logo logo-light" style="height: 69px;margin-top: -5px;">
    <span class="logo-lg" style="margin-left: -40px;">
        <img src="{{asset('upload/logo.jpg')}}" style="height: 70px;margin-top: 6px;"/>
    </span>
</a>