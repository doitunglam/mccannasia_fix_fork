
<x-component::table.test title="ádasd" />