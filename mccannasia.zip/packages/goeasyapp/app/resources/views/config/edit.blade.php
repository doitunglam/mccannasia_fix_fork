@extends('core::layout.admin')
@section('content')
<div class="container-fluid">
    
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0 font-size-18">{{$title}}</h4>

                

            </div>
            
        </div>
        
    </div>


   
    <form action="{{ route($route, $item->id) }}" method="POST" class="form-submit" enctype="multipart/form-data">	
        @csrf
        <div class="card">
            <div class="card-body">
                <div class="card">
                    <div class="card-body">
                                <?php
                                    $name = json($item->name);
                                    $value = json($item->value);
                                ?>
                                <div class="col-12">
                                    <div class="row show-html">
                                        @foreach( $name as $index => $n)
                                        @if($index == 0)
                                        <div class="get-item">
                                            @endif
                                        <div class="col-9">  
                                            <x-component::form.text name="name[]" default="Bank Name" value="{{$n}}" id="link" key="all.bank_name" placeholder="All.enter_bank_name" defaultplaceholder="Enter your name"/>
                                            <x-component::form.text name="value[]" default="Bank Account" value="{{$value[$index]}}" id="link" key="all.bank_account" placeholder="All.enter_bank_account" defaultplaceholder="Enter your account"/>
                                        </div>
                                        @if($index == 0)
                                        </div>
                                        @endif
                                        
                                        @endforeach
                                    </div>
                                </div>
                            
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="col-12">
                    <div class="row">
                        <div class="d-flex flex-wrap gap-2">
                            <x-component::form.submit default="Save"  key="all.save"/>   
                            <button class="btn btn-danger waves-effect waves-light add-bank" type="button">Add Bank</button>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </form>
</div>
@endsection()
@section('script')
@stack('c-script')
<script>
$(document).ready(function(){
   $('.add-bank').click(function(){
        var html = $('.get-item').html();
        $('.show-html').append(html);
        $('input["name=name[]"]').last().val('');
        $('input["name=value[]"]').last().val('');
   })
})
</script>
@endsection()
