<!DOCTYPE html>
<html lang="en-US">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name='robots' content='noindex, nofollow' />
	<title>MCCANNASIA</title>
	<link rel="alternate" type="application/rss+xml" title="MCCANNASIA &raquo; Feed"
		href="http://localhost/wordpress/feed/" />
	<link rel="alternate" type="application/rss+xml" title="MCCANNASIA &raquo; Comments Feed"
		href="http://localhost/wordpress/comments/feed/" />
	<script>
		window._wpemojiSettings = { "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/", "ext": ".png", "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/", "svgExt": ".svg", "source": { "concatemoji": "http:\/\/localhost\/wordpress\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1" } };
		/*! This file is auto-generated */
		!function (e, a, t) { var n, r, o, i = a.createElement("canvas"), p = i.getContext && i.getContext("2d"); function s(e, t) { var a = String.fromCharCode, e = (p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, e), 0, 0), i.toDataURL()); return p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, t), 0, 0), e === i.toDataURL() } function c(e) { var t = a.createElement("script"); t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t) } for (o = Array("flag", "emoji"), t.supports = { everything: !0, everythingExceptFlag: !0 }, r = 0; r < o.length; r++)t.supports[o[r]] = function (e) { if (p && p.fillText) switch (p.textBaseline = "top", p.font = "600 32px Arial", e) { case "flag": return s([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) ? !1 : !s([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819]) && !s([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128, 56423, 56128, 56447], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]); case "emoji": return !s([129777, 127995, 8205, 129778, 127999], [129777, 127995, 8203, 129778, 127999]) }return !1 }(o[r]), t.supports.everything = t.supports.everything && t.supports[o[r]], "flag" !== o[r] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[o[r]]); t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t.readyCallback = function () { t.DOMReady = !0 }, t.supports.everything || (n = function () { t.readyCallback() }, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function () { "complete" === a.readyState && t.readyCallback() })), (e = t.source || {}).concatemoji ? c(e.concatemoji) : e.wpemoji && e.twemoji && (c(e.twemoji), c(e.wpemoji))) }(window, document, window._wpemojiSettings);
	</script>
	<style>
		img.wp-smiley,
		img.emoji {
			display: inline !important;
			border: none !important;
			box-shadow: none !important;
			height: 1em !important;
			width: 1em !important;
			margin: 0 0.07em !important;
			vertical-align: -0.1em !important;
			background: none !important;
			padding: 0 !important;
		}
	</style>
	<style id='wp-block-site-logo-inline-css'>
		.wp-block-site-logo {
			box-sizing: border-box;
			line-height: 0
		}

		.wp-block-site-logo a {
			display: inline-block
		}

		.wp-block-site-logo.is-default-size img {
			width: 120px;
			height: auto
		}

		.wp-block-site-logo img {
			height: auto;
			max-width: 100%
		}

		.wp-block-site-logo a,
		.wp-block-site-logo img {
			border-radius: inherit
		}

		.wp-block-site-logo.aligncenter {
			margin-left: auto;
			margin-right: auto;
			text-align: center
		}

		.wp-block-site-logo.is-style-rounded {
			border-radius: 9999px
		}
	</style>
	<style id='wp-block-navigation-link-inline-css'>
		.wp-block-navigation .wp-block-navigation-item__label {
			word-break: normal;
			overflow-wrap: break-word
		}

		.wp-block-navigation .wp-block-navigation-item__description {
			display: none
		}
	</style>
	<link rel='stylesheet' id='wp-block-navigation-css' href='./css/navigation-style.min.css' media='all' />
	<style id='wp-block-navigation-inline-css'>
		.wp-block-navigation a:where(:not(.wp-element-button)) {
			color: inherit;
		}
	</style>
	<style id='wp-block-group-inline-css'>
		.wp-block-group {
			box-sizing: border-box
		}

		:where(.wp-block-group.has-background) {
			padding: 1.25em 2.375em
		}
	</style>
	<style id='wp-block-button-inline-css'>
		.wp-block-button__link {
			cursor: pointer;
			display: inline-block;
			text-align: center;
			word-break: break-word;
			box-sizing: border-box
		}

		.wp-block-button__link.aligncenter {
			text-align: center
		}

		.wp-block-button__link.alignright {
			text-align: right
		}

		:where(.wp-block-button__link) {
			box-shadow: none;
			text-decoration: none;
			border-radius: 9999px;
			padding: calc(.667em + 2px) calc(1.333em + 2px)
		}

		.wp-block-button[style*=text-decoration] .wp-block-button__link {
			text-decoration: inherit
		}

		.wp-block-buttons>.wp-block-button.has-custom-width {
			max-width: none
		}

		.wp-block-buttons>.wp-block-button.has-custom-width .wp-block-button__link {
			width: 100%
		}

		.wp-block-buttons>.wp-block-button.has-custom-font-size .wp-block-button__link {
			font-size: inherit
		}

		.wp-block-buttons>.wp-block-button.wp-block-button__width-25 {
			width: calc(25% - var(--wp--style--block-gap, .5em)*0.75)
		}

		.wp-block-buttons>.wp-block-button.wp-block-button__width-50 {
			width: calc(50% - var(--wp--style--block-gap, .5em)*0.5)
		}

		.wp-block-buttons>.wp-block-button.wp-block-button__width-75 {
			width: calc(75% - var(--wp--style--block-gap, .5em)*0.25)
		}

		.wp-block-buttons>.wp-block-button.wp-block-button__width-100 {
			width: 100%;
			flex-basis: 100%
		}

		.wp-block-buttons.is-vertical>.wp-block-button.wp-block-button__width-25 {
			width: 25%
		}

		.wp-block-buttons.is-vertical>.wp-block-button.wp-block-button__width-50 {
			width: 50%
		}

		.wp-block-buttons.is-vertical>.wp-block-button.wp-block-button__width-75 {
			width: 75%
		}

		.wp-block-button.is-style-squared,
		.wp-block-button__link.wp-block-button.is-style-squared {
			border-radius: 0
		}

		.wp-block-button.no-border-radius,
		.wp-block-button__link.no-border-radius {
			border-radius: 0 !important
		}

		.wp-block-button.is-style-outline>.wp-block-button__link,
		.wp-block-button .wp-block-button__link.is-style-outline {
			border: 2px solid;
			padding: .667em 1.333em
		}

		.wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color),
		.wp-block-button .wp-block-button__link.is-style-outline:not(.has-text-color) {
			color: currentColor
		}

		.wp-block-button.is-style-outline>.wp-block-button__link:not(.has-background),
		.wp-block-button .wp-block-button__link.is-style-outline:not(.has-background) {
			background-color: transparent;
			background-image: none
		}

		.wp-block-button .wp-block-button__link {
			background-color: var(--wp--preset--color--primary);
			border-radius: 0;
			color: var(--wp--preset--color--background);
			font-size: var(--wp--preset--font-size--medium);
		}
	</style>
	<style id='wp-block-buttons-inline-css'>
		.wp-block-buttons.is-vertical {
			flex-direction: column
		}

		.wp-block-buttons.is-vertical>.wp-block-button:last-child {
			margin-bottom: 0
		}

		.wp-block-buttons>.wp-block-button {
			display: inline-block;
			margin: 0
		}

		.wp-block-buttons.is-content-justification-left {
			justify-content: flex-start
		}

		.wp-block-buttons.is-content-justification-left.is-vertical {
			align-items: flex-start
		}

		.wp-block-buttons.is-content-justification-center {
			justify-content: center
		}

		.wp-block-buttons.is-content-justification-center.is-vertical {
			align-items: center
		}

		.wp-block-buttons.is-content-justification-right {
			justify-content: flex-end
		}

		.wp-block-buttons.is-content-justification-right.is-vertical {
			align-items: flex-end
		}

		.wp-block-buttons.is-content-justification-space-between {
			justify-content: space-between
		}

		.wp-block-buttons.aligncenter {
			text-align: center
		}

		.wp-block-buttons:not(.is-content-justification-space-between, .is-content-justification-right, .is-content-justification-left, .is-content-justification-center) .wp-block-button.aligncenter {
			margin-left: auto;
			margin-right: auto;
			width: 100%
		}

		.wp-block-buttons[style*=text-decoration] .wp-block-button,
		.wp-block-buttons[style*=text-decoration] .wp-block-button__link {
			text-decoration: inherit
		}

		.wp-block-buttons.has-custom-font-size .wp-block-button__link {
			font-size: inherit
		}

		.wp-block-button.aligncenter {
			text-align: center
		}
	</style>
	<style id='wp-block-template-part-inline-css'>
		.wp-block-template-part.has-background {
			padding: 1.25em 2.375em;
			margin-top: 0;
			margin-bottom: 0
		}
	</style>
	<style id='wp-block-heading-inline-css'>
		h1.has-background,
		h2.has-background,
		h3.has-background,
		h4.has-background,
		h5.has-background,
		h6.has-background {
			padding: 1.25em 2.375em
		}
	</style>
	<style id='wp-block-image-inline-css'>
		.wp-block-image img {
			height: auto;
			max-width: 100%;
			vertical-align: bottom
		}

		.wp-block-image.has-custom-border img,
		.wp-block-image img {
			box-sizing: border-box
		}

		.wp-block-image.aligncenter {
			text-align: center
		}

		.wp-block-image.alignfull img,
		.wp-block-image.alignwide img {
			height: auto;
			width: 100%
		}

		.wp-block-image.aligncenter,
		.wp-block-image .aligncenter,
		.wp-block-image.alignleft,
		.wp-block-image .alignleft,
		.wp-block-image.alignright,
		.wp-block-image .alignright {
			display: table
		}

		.wp-block-image.aligncenter>figcaption,
		.wp-block-image .aligncenter>figcaption,
		.wp-block-image.alignleft>figcaption,
		.wp-block-image .alignleft>figcaption,
		.wp-block-image.alignright>figcaption,
		.wp-block-image .alignright>figcaption {
			display: table-caption;
			caption-side: bottom
		}

		.wp-block-image .alignleft {
			float: left;
			margin: .5em 1em .5em 0
		}

		.wp-block-image .alignright {
			float: right;
			margin: .5em 0 .5em 1em
		}

		.wp-block-image .aligncenter {
			margin-left: auto;
			margin-right: auto
		}

		.wp-block-image figcaption {
			margin-top: .5em;
			margin-bottom: 1em
		}

		.wp-block-image.is-style-circle-mask img,
		.wp-block-image.is-style-rounded img,
		.wp-block-image .is-style-rounded img {
			border-radius: 9999px
		}

		@supports ((-webkit-mask-image:none) or (mask-image:none)) or (-webkit-mask-image:none) {
			.wp-block-image.is-style-circle-mask img {
				-webkit-mask-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50"/></svg>');
				mask-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="50"/></svg>');
				mask-mode: alpha;
				-webkit-mask-repeat: no-repeat;
				mask-repeat: no-repeat;
				-webkit-mask-size: contain;
				mask-size: contain;
				-webkit-mask-position: center;
				mask-position: center;
				border-radius: 0
			}
		}

		.wp-block-image :where(.has-border-color) {
			border-style: solid
		}

		.wp-block-image :where([style*=border-top-color]) {
			border-top-style: solid
		}

		.wp-block-image :where([style*=border-right-color]) {
			border-right-style: solid
		}

		.wp-block-image :where([style*=border-bottom-color]) {
			border-bottom-style: solid
		}

		.wp-block-image :where([style*=border-left-color]) {
			border-left-style: solid
		}

		.wp-block-image :where([style*=border-width]) {
			border-style: solid
		}

		.wp-block-image :where([style*=border-top-width]) {
			border-top-style: solid
		}

		.wp-block-image :where([style*=border-right-width]) {
			border-right-style: solid
		}

		.wp-block-image :where([style*=border-bottom-width]) {
			border-bottom-style: solid
		}

		.wp-block-image :where([style*=border-left-width]) {
			border-left-style: solid
		}

		.wp-block-image figure {
			margin: 0
		}

		.wp-block-image figcaption {
			color: #555;
			font-size: 13px;
			text-align: center
		}

		.is-dark-theme .wp-block-image figcaption {
			color: hsla(0, 0%, 100%, .65)
		}

		.wp-block-image {
			margin: 0 0 1em
		}
	</style>
	<style id='wp-block-spacer-inline-css'>
		.wp-block-spacer {
			clear: both
		}
	</style>
	<style id='wp-block-post-template-inline-css'>
		.wp-block-post-template {
			margin-top: 0;
			margin-bottom: 0;
			max-width: 100%;
			list-style: none;
			padding: 0
		}

		.wp-block-post-template.wp-block-post-template {
			background: none
		}

		.wp-block-post-template.is-flex-container {
			flex-direction: row;
			display: flex;
			flex-wrap: wrap;
			gap: 1.25em
		}

		.wp-block-post-template.is-flex-container li {
			margin: 0;
			width: 100%
		}

		@media (min-width:600px) {
			.wp-block-post-template.is-flex-container.is-flex-container.columns-2>li {
				width: calc(50% - .625em)
			}

			.wp-block-post-template.is-flex-container.is-flex-container.columns-3>li {
				width: calc(33.33333% - .83333em)
			}

			.wp-block-post-template.is-flex-container.is-flex-container.columns-4>li {
				width: calc(25% - .9375em)
			}

			.wp-block-post-template.is-flex-container.is-flex-container.columns-5>li {
				width: calc(20% - 1em)
			}

			.wp-block-post-template.is-flex-container.is-flex-container.columns-6>li {
				width: calc(16.66667% - 1.04167em)
			}
		}
	</style>
	<style id='wp-block-list-inline-css'>
		ol,
		ul {
			box-sizing: border-box
		}

		ol.has-background,
		ul.has-background {
			padding: 1.25em 2.375em
		}
	</style>
	<style id='wp-block-paragraph-inline-css'>
		.is-small-text {
			font-size: .875em
		}

		.is-regular-text {
			font-size: 1em
		}

		.is-large-text {
			font-size: 2.25em
		}

		.is-larger-text {
			font-size: 3em
		}

		.has-drop-cap:not(:focus):first-letter {
			float: left;
			font-size: 8.4em;
			line-height: .68;
			font-weight: 100;
			margin: .05em .1em 0 0;
			text-transform: uppercase;
			font-style: normal
		}

		p.has-drop-cap.has-background {
			overflow: hidden
		}

		p.has-background {
			padding: 1.25em 2.375em
		}

		:where(p.has-text-color:not(.has-link-color)) a {
			color: inherit
		}
	</style>
	<style id='wp-block-columns-inline-css'>
		.wp-block-columns {
			display: flex;
			margin-bottom: 1.75em;
			box-sizing: border-box;
			flex-wrap: wrap !important;
			align-items: normal !important
		}

		@media (min-width:782px) {
			.wp-block-columns {
				flex-wrap: nowrap !important
			}
		}

		.wp-block-columns.are-vertically-aligned-top {
			align-items: flex-start
		}

		.wp-block-columns.are-vertically-aligned-center {
			align-items: center
		}

		.wp-block-columns.are-vertically-aligned-bottom {
			align-items: flex-end
		}

		@media (max-width:781px) {
			.wp-block-columns:not(.is-not-stacked-on-mobile)>.wp-block-column {
				flex-basis: 100% !important
			}
		}

		@media (min-width:782px) {
			.wp-block-columns:not(.is-not-stacked-on-mobile)>.wp-block-column {
				flex-basis: 0;
				flex-grow: 1
			}

			.wp-block-columns:not(.is-not-stacked-on-mobile)>.wp-block-column[style*=flex-basis] {
				flex-grow: 0
			}
		}

		.wp-block-columns.is-not-stacked-on-mobile {
			flex-wrap: nowrap !important
		}

		.wp-block-columns.is-not-stacked-on-mobile>.wp-block-column {
			flex-basis: 0;
			flex-grow: 1
		}

		.wp-block-columns.is-not-stacked-on-mobile>.wp-block-column[style*=flex-basis] {
			flex-grow: 0
		}

		:where(.wp-block-columns.has-background) {
			padding: 1.25em 2.375em
		}

		.wp-block-column {
			flex-grow: 1;
			min-width: 0;
			word-break: break-word;
			overflow-wrap: break-word
		}

		.wp-block-column.is-vertically-aligned-top {
			align-self: flex-start
		}

		.wp-block-column.is-vertically-aligned-center {
			align-self: center
		}

		.wp-block-column.is-vertically-aligned-bottom {
			align-self: flex-end
		}

		.wp-block-column.is-vertically-aligned-bottom,
		.wp-block-column.is-vertically-aligned-center,
		.wp-block-column.is-vertically-aligned-top {
			width: 100%
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-25-inline-css'>
		.wp-duotone-000000-f6f6f6-25 img,
		.wp-duotone-000000-f6f6f6-25 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-25') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-29-inline-css'>
		.wp-duotone-000000-f6f6f6-29 img,
		.wp-duotone-000000-f6f6f6-29 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-29') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-33-inline-css'>
		.wp-duotone-000000-f6f6f6-33 img,
		.wp-duotone-000000-f6f6f6-33 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-33') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-37-inline-css'>
		.wp-duotone-000000-f6f6f6-37 img,
		.wp-duotone-000000-f6f6f6-37 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-37') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-41-inline-css'>
		.wp-duotone-000000-f6f6f6-41 img,
		.wp-duotone-000000-f6f6f6-41 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-41') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-45-inline-css'>
		.wp-duotone-000000-f6f6f6-45 img,
		.wp-duotone-000000-f6f6f6-45 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-45') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-49-inline-css'>
		.wp-duotone-000000-f6f6f6-49 img,
		.wp-duotone-000000-f6f6f6-49 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-49') !important;
		}
	</style>
	<style id='wp-duotone-000000-f6f6f6-53-inline-css'>
		.wp-duotone-000000-f6f6f6-53 img,
		.wp-duotone-000000-f6f6f6-53 .components-placeholder {
			filter: url('#wp-duotone-000000-f6f6f6-53') !important;
		}
	</style>
	<style id='wp-block-library-inline-css'>
		:root {
			--wp-admin-theme-color: #007cba;
			--wp-admin-theme-color--rgb: 0, 124, 186;
			--wp-admin-theme-color-darker-10: #006ba1;
			--wp-admin-theme-color-darker-10--rgb: 0, 107, 161;
			--wp-admin-theme-color-darker-20: #005a87;
			--wp-admin-theme-color-darker-20--rgb: 0, 90, 135;
			--wp-admin-border-width-focus: 2px
		}

		@media (-webkit-min-device-pixel-ratio:2),
		(min-resolution:192dpi) {
			:root {
				--wp-admin-border-width-focus: 1.5px
			}
		}

		.wp-element-button {
			cursor: pointer
		}

		:root {
			--wp--preset--font-size--normal: 16px;
			--wp--preset--font-size--huge: 42px
		}

		:root .has-very-light-gray-background-color {
			background-color: #eee
		}

		:root .has-very-dark-gray-background-color {
			background-color: #313131
		}

		:root .has-very-light-gray-color {
			color: #eee
		}

		:root .has-very-dark-gray-color {
			color: #313131
		}

		:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background {
			background: linear-gradient(135deg, #00d084, #0693e3)
		}

		:root .has-purple-crush-gradient-background {
			background: linear-gradient(135deg, #34e2e4, #4721fb 50%, #ab1dfe)
		}

		:root .has-hazy-dawn-gradient-background {
			background: linear-gradient(135deg, #faaca8, #dad0ec)
		}

		:root .has-subdued-olive-gradient-background {
			background: linear-gradient(135deg, #fafae1, #67a671)
		}

		:root .has-atomic-cream-gradient-background {
			background: linear-gradient(135deg, #fdd79a, #004a59)
		}

		:root .has-nightshade-gradient-background {
			background: linear-gradient(135deg, #330968, #31cdcf)
		}

		:root .has-midnight-gradient-background {
			background: linear-gradient(135deg, #020381, #2874fc)
		}

		.has-regular-font-size {
			font-size: 1em
		}

		.has-larger-font-size {
			font-size: 2.625em
		}

		.has-normal-font-size {
			font-size: var(--wp--preset--font-size--normal)
		}

		.has-huge-font-size {
			font-size: var(--wp--preset--font-size--huge)
		}

		.has-text-align-center {
			text-align: center
		}

		.has-text-align-left {
			text-align: left
		}

		.has-text-align-right {
			text-align: right
		}

		#end-resizable-editor-section {
			display: none
		}

		.aligncenter {
			clear: both
		}

		.items-justified-left {
			justify-content: flex-start
		}

		.items-justified-center {
			justify-content: center
		}

		.items-justified-right {
			justify-content: flex-end
		}

		.items-justified-space-between {
			justify-content: space-between
		}

		.screen-reader-text {
			border: 0;
			clip: rect(1px, 1px, 1px, 1px);
			clip-path: inset(50%);
			height: 1px;
			margin: -1px;
			overflow: hidden;
			padding: 0;
			position: absolute;
			width: 1px;
			word-wrap: normal !important
		}

		.screen-reader-text:focus {
			background-color: #ddd;
			clip: auto !important;
			clip-path: none;
			color: #444;
			display: block;
			font-size: 1em;
			height: auto;
			left: 5px;
			line-height: normal;
			padding: 15px 23px 14px;
			text-decoration: none;
			top: 5px;
			width: auto;
			z-index: 100000
		}

		html :where(.has-border-color) {
			border-style: solid
		}

		html :where([style*=border-top-color]) {
			border-top-style: solid
		}

		html :where([style*=border-right-color]) {
			border-right-style: solid
		}

		html :where([style*=border-bottom-color]) {
			border-bottom-style: solid
		}

		html :where([style*=border-left-color]) {
			border-left-style: solid
		}

		html :where([style*=border-width]) {
			border-style: solid
		}

		html :where([style*=border-top-width]) {
			border-top-style: solid
		}

		html :where([style*=border-right-width]) {
			border-right-style: solid
		}

		html :where([style*=border-bottom-width]) {
			border-bottom-style: solid
		}

		html :where([style*=border-left-width]) {
			border-left-style: solid
		}

		html :where(img[class*=wp-image-]) {
			height: auto;
			max-width: 100%
		}

		figure {
			margin: 0 0 1em
		}
	</style>
	<style id='global-styles-inline-css'>
		body {
			--wp--preset--color--black: #000000;
			--wp--preset--color--cyan-bluish-gray: #abb8c3;
			--wp--preset--color--white: #ffffff;
			--wp--preset--color--pale-pink: #f78da7;
			--wp--preset--color--vivid-red: #cf2e2e;
			--wp--preset--color--luminous-vivid-orange: #ff6900;
			--wp--preset--color--luminous-vivid-amber: #fcb900;
			--wp--preset--color--light-green-cyan: #7bdcb5;
			--wp--preset--color--vivid-green-cyan: #00d084;
			--wp--preset--color--pale-cyan-blue: #8ed1fc;
			--wp--preset--color--vivid-cyan-blue: #0693e3;
			--wp--preset--color--vivid-purple: #9b51e0;
			--wp--preset--color--foreground: #000000;
			--wp--preset--color--background: #ffffff;
			--wp--preset--color--primary: #1a4548;
			--wp--preset--color--secondary: #ffe2c7;
			--wp--preset--color--tertiary: #F6F6F6;
			--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
			--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
			--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
			--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
			--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
			--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
			--wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
			--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
			--wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
			--wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
			--wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
			--wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
			--wp--preset--gradient--vertical-secondary-to-tertiary: linear-gradient(to bottom, var(--wp--preset--color--secondary) 0%, var(--wp--preset--color--tertiary) 100%);
			--wp--preset--gradient--vertical-secondary-to-background: linear-gradient(to bottom, var(--wp--preset--color--secondary) 0%, var(--wp--preset--color--background) 100%);
			--wp--preset--gradient--vertical-tertiary-to-background: linear-gradient(to bottom, var(--wp--preset--color--tertiary) 0%, var(--wp--preset--color--background) 100%);
			--wp--preset--gradient--diagonal-primary-to-foreground: linear-gradient(to bottom right, var(--wp--preset--color--primary) 0%, var(--wp--preset--color--foreground) 100%);
			--wp--preset--gradient--diagonal-secondary-to-background: linear-gradient(to bottom right, var(--wp--preset--color--secondary) 50%, var(--wp--preset--color--background) 50%);
			--wp--preset--gradient--diagonal-background-to-secondary: linear-gradient(to bottom right, var(--wp--preset--color--background) 50%, var(--wp--preset--color--secondary) 50%);
			--wp--preset--gradient--diagonal-tertiary-to-background: linear-gradient(to bottom right, var(--wp--preset--color--tertiary) 50%, var(--wp--preset--color--background) 50%);
			--wp--preset--gradient--diagonal-background-to-tertiary: linear-gradient(to bottom right, var(--wp--preset--color--background) 50%, var(--wp--preset--color--tertiary) 50%);
			--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');
			--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');
			--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');
			--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');
			--wp--preset--duotone--midnight: url('#wp-duotone-midnight');
			--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');
			--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');
			--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');
			--wp--preset--duotone--foreground-and-background: url('#wp-duotone-foreground-and-background');
			--wp--preset--duotone--foreground-and-secondary: url('#wp-duotone-foreground-and-secondary');
			--wp--preset--duotone--foreground-and-tertiary: url('#wp-duotone-foreground-and-tertiary');
			--wp--preset--duotone--primary-and-background: url('#wp-duotone-primary-and-background');
			--wp--preset--duotone--primary-and-secondary: url('#wp-duotone-primary-and-secondary');
			--wp--preset--duotone--primary-and-tertiary: url('#wp-duotone-primary-and-tertiary');
			--wp--preset--font-size--small: 1rem;
			--wp--preset--font-size--medium: 1.125rem;
			--wp--preset--font-size--large: 1.75rem;
			--wp--preset--font-size--x-large: clamp(1.75rem, 3vw, 2.25rem);
			--wp--preset--font-family--system-font: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
			--wp--preset--font-family--source-serif-pro: "Source Serif Pro", serif;
			--wp--preset--spacing--20: 0.44rem;
			--wp--preset--spacing--30: 0.67rem;
			--wp--preset--spacing--40: 1rem;
			--wp--preset--spacing--50: 1.5rem;
			--wp--preset--spacing--60: 2.25rem;
			--wp--preset--spacing--70: 3.38rem;
			--wp--preset--spacing--80: 5.06rem;
			--wp--custom--spacing--small: max(1.25rem, 5vw);
			--wp--custom--spacing--medium: clamp(2rem, 8vw, calc(4 * var(--wp--style--block-gap)));
			--wp--custom--spacing--large: clamp(4rem, 10vw, 8rem);
			--wp--custom--spacing--outer: var(--wp--custom--spacing--small, 1.25rem);
			--wp--custom--typography--font-size--huge: clamp(2.25rem, 4vw, 2.75rem);
			--wp--custom--typography--font-size--gigantic: clamp(2.75rem, 6vw, 3.25rem);
			--wp--custom--typography--font-size--colossal: clamp(3.25rem, 8vw, 6.25rem);
			--wp--custom--typography--line-height--tiny: 1.15;
			--wp--custom--typography--line-height--small: 1.2;
			--wp--custom--typography--line-height--medium: 1.4;
			--wp--custom--typography--line-height--normal: 1.6;
		}

		body {
			margin: 0;
			--wp--style--global--content-size: 650px;
			--wp--style--global--wide-size: 1000px;
		}

		.wp-site-blocks>.alignleft {
			float: left;
			margin-right: 2em;
		}

		.wp-site-blocks>.alignright {
			float: right;
			margin-left: 2em;
		}

		.wp-site-blocks>.aligncenter {
			justify-content: center;
			margin-left: auto;
			margin-right: auto;
		}

		.wp-site-blocks>* {
			margin-block-start: 0;
			margin-block-end: 0;
		}

		.wp-site-blocks>*+* {
			margin-block-start: 1.5rem;
		}

		body {
			--wp--style--block-gap: 1.5rem;
		}

		body .is-layout-flow>* {
			margin-block-start: 0;
			margin-block-end: 0;
		}

		body .is-layout-flow>*+* {
			margin-block-start: 1.5rem;
			margin-block-end: 0;
		}

		body .is-layout-constrained>* {
			margin-block-start: 0;
			margin-block-end: 0;
		}

		body .is-layout-constrained>*+* {
			margin-block-start: 1.5rem;
			margin-block-end: 0;
		}

		body .is-layout-flex {
			gap: 1.5rem;
		}

		body .is-layout-flow>.alignleft {
			float: left;
			margin-inline-start: 0;
			margin-inline-end: 2em;
		}

		body .is-layout-flow>.alignright {
			float: right;
			margin-inline-start: 2em;
			margin-inline-end: 0;
		}

		body .is-layout-flow>.aligncenter {
			margin-left: auto !important;
			margin-right: auto !important;
		}

		body .is-layout-constrained>.alignleft {
			float: left;
			margin-inline-start: 0;
			margin-inline-end: 2em;
		}

		body .is-layout-constrained>.alignright {
			float: right;
			margin-inline-start: 2em;
			margin-inline-end: 0;
		}

		body .is-layout-constrained>.aligncenter {
			margin-left: auto !important;
			margin-right: auto !important;
		}

		body .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
			max-width: var(--wp--style--global--content-size);
			margin-left: auto !important;
			margin-right: auto !important;
		}

		body .is-layout-constrained>.alignwide {
			max-width: var(--wp--style--global--wide-size);
		}

		body .is-layout-flex {
			display: flex;
		}

		body .is-layout-flex {
			flex-wrap: wrap;
			align-items: center;
		}

		body .is-layout-flex>* {
			margin: 0;
		}

		body {
			background-color: var(--wp--preset--color--background);
			color: var(--wp--preset--color--foreground);
			font-family: var(--wp--preset--font-family--system-font);
			font-size: var(--wp--preset--font-size--medium);
			line-height: var(--wp--custom--typography--line-height--normal);
			padding-top: 0px;
			padding-right: 0px;
			padding-bottom: 0px;
			padding-left: 0px;
		}

		a:where(:not(.wp-element-button)) {
			color: var(--wp--preset--color--foreground);
			text-decoration: underline;
		}

		h1 {
			font-family: var(--wp--preset--font-family--source-serif-pro);
			font-size: var(--wp--custom--typography--font-size--colossal);
			font-weight: 300;
			line-height: var(--wp--custom--typography--line-height--tiny);
		}

		h2 {
			font-family: var(--wp--preset--font-family--source-serif-pro);
			font-size: var(--wp--custom--typography--font-size--gigantic);
			font-weight: 300;
			line-height: var(--wp--custom--typography--line-height--small);
		}

		h3 {
			font-family: var(--wp--preset--font-family--source-serif-pro);
			font-size: var(--wp--custom--typography--font-size--huge);
			font-weight: 300;
			line-height: var(--wp--custom--typography--line-height--tiny);
		}

		h4 {
			font-family: var(--wp--preset--font-family--source-serif-pro);
			font-size: var(--wp--preset--font-size--x-large);
			font-weight: 300;
			line-height: var(--wp--custom--typography--line-height--tiny);
		}

		h5 {
			font-family: var(--wp--preset--font-family--system-font);
			font-size: var(--wp--preset--font-size--medium);
			font-weight: 700;
			line-height: var(--wp--custom--typography--line-height--normal);
			text-transform: uppercase;
		}

		h6 {
			font-family: var(--wp--preset--font-family--system-font);
			font-size: var(--wp--preset--font-size--medium);
			font-weight: 400;
			line-height: var(--wp--custom--typography--line-height--normal);
			text-transform: uppercase;
		}

		.wp-element-button,
		.wp-block-button__link {
			background-color: #32373c;
			border-width: 0;
			color: #fff;
			font-family: inherit;
			font-size: inherit;
			line-height: inherit;
			padding: calc(0.667em + 2px) calc(1.333em + 2px);
			text-decoration: none;
		}

		.has-black-color {
			color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-color {
			color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-color {
			color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-color {
			color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-color {
			color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-color {
			color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-color {
			color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-color {
			color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-color {
			color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-color {
			color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-color {
			color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-color {
			color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-foreground-color {
			color: var(--wp--preset--color--foreground) !important;
		}

		.has-background-color {
			color: var(--wp--preset--color--background) !important;
		}

		.has-primary-color {
			color: var(--wp--preset--color--primary) !important;
		}

		.has-secondary-color {
			color: var(--wp--preset--color--secondary) !important;
		}

		.has-tertiary-color {
			color: var(--wp--preset--color--tertiary) !important;
		}

		.has-black-background-color {
			background-color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-background-color {
			background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-background-color {
			background-color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-background-color {
			background-color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-background-color {
			background-color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-background-color {
			background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-background-color {
			background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-background-color {
			background-color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-background-color {
			background-color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-background-color {
			background-color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-background-color {
			background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-background-color {
			background-color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-foreground-background-color {
			background-color: var(--wp--preset--color--foreground) !important;
		}

		.has-background-background-color {
			background-color: var(--wp--preset--color--background) !important;
		}

		.has-primary-background-color {
			background-color: var(--wp--preset--color--primary) !important;
		}

		.has-secondary-background-color {
			background-color: var(--wp--preset--color--secondary) !important;
		}

		.has-tertiary-background-color {
			background-color: var(--wp--preset--color--tertiary) !important;
		}

		.has-black-border-color {
			border-color: var(--wp--preset--color--black) !important;
		}

		.has-cyan-bluish-gray-border-color {
			border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
		}

		.has-white-border-color {
			border-color: var(--wp--preset--color--white) !important;
		}

		.has-pale-pink-border-color {
			border-color: var(--wp--preset--color--pale-pink) !important;
		}

		.has-vivid-red-border-color {
			border-color: var(--wp--preset--color--vivid-red) !important;
		}

		.has-luminous-vivid-orange-border-color {
			border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-amber-border-color {
			border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
		}

		.has-light-green-cyan-border-color {
			border-color: var(--wp--preset--color--light-green-cyan) !important;
		}

		.has-vivid-green-cyan-border-color {
			border-color: var(--wp--preset--color--vivid-green-cyan) !important;
		}

		.has-pale-cyan-blue-border-color {
			border-color: var(--wp--preset--color--pale-cyan-blue) !important;
		}

		.has-vivid-cyan-blue-border-color {
			border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
		}

		.has-vivid-purple-border-color {
			border-color: var(--wp--preset--color--vivid-purple) !important;
		}

		.has-foreground-border-color {
			border-color: var(--wp--preset--color--foreground) !important;
		}

		.has-background-border-color {
			border-color: var(--wp--preset--color--background) !important;
		}

		.has-primary-border-color {
			border-color: var(--wp--preset--color--primary) !important;
		}

		.has-secondary-border-color {
			border-color: var(--wp--preset--color--secondary) !important;
		}

		.has-tertiary-border-color {
			border-color: var(--wp--preset--color--tertiary) !important;
		}

		.has-vivid-cyan-blue-to-vivid-purple-gradient-background {
			background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
		}

		.has-light-green-cyan-to-vivid-green-cyan-gradient-background {
			background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
		}

		.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
			background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
		}

		.has-luminous-vivid-orange-to-vivid-red-gradient-background {
			background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
		}

		.has-very-light-gray-to-cyan-bluish-gray-gradient-background {
			background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
		}

		.has-cool-to-warm-spectrum-gradient-background {
			background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
		}

		.has-blush-light-purple-gradient-background {
			background: var(--wp--preset--gradient--blush-light-purple) !important;
		}

		.has-blush-bordeaux-gradient-background {
			background: var(--wp--preset--gradient--blush-bordeaux) !important;
		}

		.has-luminous-dusk-gradient-background {
			background: var(--wp--preset--gradient--luminous-dusk) !important;
		}

		.has-pale-ocean-gradient-background {
			background: var(--wp--preset--gradient--pale-ocean) !important;
		}

		.has-electric-grass-gradient-background {
			background: var(--wp--preset--gradient--electric-grass) !important;
		}

		.has-midnight-gradient-background {
			background: var(--wp--preset--gradient--midnight) !important;
		}

		.has-vertical-secondary-to-tertiary-gradient-background {
			background: var(--wp--preset--gradient--vertical-secondary-to-tertiary) !important;
		}

		.has-vertical-secondary-to-background-gradient-background {
			background: var(--wp--preset--gradient--vertical-secondary-to-background) !important;
		}

		.has-vertical-tertiary-to-background-gradient-background {
			background: var(--wp--preset--gradient--vertical-tertiary-to-background) !important;
		}

		.has-diagonal-primary-to-foreground-gradient-background {
			background: var(--wp--preset--gradient--diagonal-primary-to-foreground) !important;
		}

		.has-diagonal-secondary-to-background-gradient-background {
			background: var(--wp--preset--gradient--diagonal-secondary-to-background) !important;
		}

		.has-diagonal-background-to-secondary-gradient-background {
			background: var(--wp--preset--gradient--diagonal-background-to-secondary) !important;
		}

		.has-diagonal-tertiary-to-background-gradient-background {
			background: var(--wp--preset--gradient--diagonal-tertiary-to-background) !important;
		}

		.has-diagonal-background-to-tertiary-gradient-background {
			background: var(--wp--preset--gradient--diagonal-background-to-tertiary) !important;
		}

		.has-small-font-size {
			font-size: var(--wp--preset--font-size--small) !important;
		}

		.has-medium-font-size {
			font-size: var(--wp--preset--font-size--medium) !important;
		}

		.has-large-font-size {
			font-size: var(--wp--preset--font-size--large) !important;
		}

		.has-x-large-font-size {
			font-size: var(--wp--preset--font-size--x-large) !important;
		}

		.has-system-font-font-family {
			font-family: var(--wp--preset--font-family--system-font) !important;
		}

		.has-source-serif-pro-font-family {
			font-family: var(--wp--preset--font-family--source-serif-pro) !important;
		}
	</style>
	<style id='core-block-supports-inline-css'>
		.wp-elements-52ccb10a34611d4cd3707ed50c923d88 a {
			color: var(--wp--preset--color--background);
		}

		.wp-block-group.wp-container-5 {
			justify-content: space-between;
		}

		.wp-block-columns.wp-container-57 {
			flex-wrap: nowrap;
			gap: var(--wp--preset--spacing--80) var(--wp--preset--spacing--80);
		}

		.wp-block-columns.wp-container-77 {
			flex-wrap: nowrap;
			gap: 0 0;
		}

		.wp-block-group.wp-container-7>*,
		.wp-block-group.wp-container-7.wp-block-group.wp-container-7>*+*,
		.wp-block-group.wp-container-26>*,
		.wp-block-group.wp-container-26.wp-block-group.wp-container-26>*+*,
		.wp-block-group.wp-container-30>*,
		.wp-block-group.wp-container-30.wp-block-group.wp-container-30>*+*,
		.wp-block-group.wp-container-34>*,
		.wp-block-group.wp-container-34.wp-block-group.wp-container-34>*+*,
		.wp-block-group.wp-container-38>*,
		.wp-block-group.wp-container-38.wp-block-group.wp-container-38>*+*,
		.wp-block-group.wp-container-42>*,
		.wp-block-group.wp-container-42.wp-block-group.wp-container-42>*+*,
		.wp-block-group.wp-container-46>*,
		.wp-block-group.wp-container-46.wp-block-group.wp-container-46>*+*,
		.wp-block-group.wp-container-50>*,
		.wp-block-group.wp-container-50.wp-block-group.wp-container-50>*+*,
		.wp-block-group.wp-container-54>*,
		.wp-block-group.wp-container-54.wp-block-group.wp-container-54>*+* {
			margin-block-start: 0;
			margin-block-end: 0;
		}

		.wp-block-columns.wp-container-14,
		.wp-block-group.wp-container-15,
		.wp-block-columns.wp-container-17,
		.wp-block-group.wp-container-18,
		.wp-block-columns.wp-container-20,
		.wp-block-group.wp-container-21,
		.wp-block-columns.wp-container-23,
		.wp-block-columns.wp-container-70 {
			flex-wrap: nowrap;
		}
	</style>
	<link rel='stylesheet' id='bodhi-svgs-attachment-css' href='./css/svg-support-css-svgs-attachment.css'
		media='all' />
	<style id='wp-webfonts-inline-css'>
		@font-face {
			font-family: "Source Serif Pro";
			font-style: normal;
			font-weight: 200 900;
			font-display: fallback;
			src: local("Source Serif Pro"), url('./fonts/SourceSerif4Variable-Roman.ttf.woff2') format('woff2');
			font-stretch: normal;
		}

		@font-face {
			font-family: "Source Serif Pro";
			font-style: italic;
			font-weight: 200 900;
			font-display: fallback;
			src: local("Source Serif Pro"), url('./fonts/SourceSerif4Variable-Italic.ttf.woff2') format('woff2');
			font-stretch: normal;
		}
	</style>
	<link rel='stylesheet' id='twentytwentytwo-style-css' href='./css/twentytwentytwo-style.css' media='all' />
	<script>
		/* <![CDATA[ */
		var rcewpp = {
			"ajax_url": "http://localhost/wordpress/wp-admin/admin-ajax.php",
			"nonce": "3c9504d696",
			"home_url": "http://localhost/wordpress/",
			"settings_icon": 'http://localhost/wordpress/wp-content/plugins/export-wp-page-to-static-html/admin/images/settings.png',
			"settings_hover_icon": 'http://localhost/wordpress/wp-content/plugins/export-wp-page-to-static-html/admin/images/settings_hover.png'
		};
            /* ]]\> */
	</script>
	<link rel="stylesheet" type="text/css"
		href="./css/smart-slider-3-Public-SmartSlider3-Application-Frontend-Assets-dist-smartslider.min.css"
		media="all">
	<link rel="stylesheet" type="text/css"
		href="https://fonts.googleapis.com/css?display=swap&amp;family=Playfair+Display%3A300%2C400" media="all">
	<style data-related="n2-ss-2">
		div#n2-ss-2 .n2-ss-slider-1 {
			display: grid;
			position: relative;
		}

		div#n2-ss-2 .n2-ss-slider-2 {
			display: grid;
			position: relative;
			overflow: hidden;
			padding: 0px 0px 0px 0px;
			border: 0px solid RGBA(62, 62, 62, 1);
			border-radius: 0px;
			background-clip: padding-box;
			background-repeat: repeat;
			background-position: 50% 50%;
			background-size: cover;
			background-attachment: scroll;
			z-index: 1;
		}

		div#n2-ss-2:not(.n2-ss-loaded) .n2-ss-slider-2 {
			background-image: none !important;
		}

		div#n2-ss-2 .n2-ss-slider-3 {
			display: grid;
			grid-template-areas: 'cover';
			position: relative;
			overflow: hidden;
			z-index: 10;
		}

		div#n2-ss-2 .n2-ss-slider-3>* {
			grid-area: cover;
		}

		div#n2-ss-2 .n2-ss-slide-backgrounds,
		div#n2-ss-2 .n2-ss-slider-3>.n2-ss-divider {
			position: relative;
		}

		div#n2-ss-2 .n2-ss-slide-backgrounds {
			z-index: 10;
		}

		div#n2-ss-2 .n2-ss-slide-backgrounds>* {
			overflow: hidden;
		}

		div#n2-ss-2 .n2-ss-slide-background {
			transform: translateX(-100000px);
		}

		div#n2-ss-2 .n2-ss-slider-4 {
			place-self: center;
			position: relative;
			width: 100%;
			height: 100%;
			z-index: 20;
			display: grid;
			grid-template-areas: 'slide';
		}

		div#n2-ss-2 .n2-ss-slider-4>* {
			grid-area: slide;
		}

		div#n2-ss-2.n2-ss-full-page--constrain-ratio .n2-ss-slider-4 {
			height: auto;
		}

		div#n2-ss-2 .n2-ss-slide {
			display: grid;
			place-items: center;
			grid-auto-columns: 100%;
			position: relative;
			z-index: 20;
			-webkit-backface-visibility: hidden;
			transform: translateX(-100000px);
		}

		div#n2-ss-2 .n2-ss-slide {
			perspective: 1500px;
		}

		div#n2-ss-2 .n2-ss-slide-active {
			z-index: 21;
		}

		.n2-ss-background-animation {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			z-index: 3;
		}

		div#n2-ss-2 .n2-ss-button-container,
		div#n2-ss-2 .n2-ss-button-container a {
			display: block;
		}

		div#n2-ss-2 .n2-ss-button-container--non-full-width,
		div#n2-ss-2 .n2-ss-button-container--non-full-width a {
			display: inline-block;
		}

		div#n2-ss-2 .n2-ss-button-container.n2-ss-nowrap {
			white-space: nowrap;
		}

		div#n2-ss-2 .n2-ss-button-container a div {
			display: inline;
			font-size: inherit;
			text-decoration: inherit;
			color: inherit;
			line-height: inherit;
			font-family: inherit;
			font-weight: inherit;
		}

		div#n2-ss-2 .n2-ss-button-container a>div {
			display: inline-flex;
			align-items: center;
			vertical-align: top;
		}

		div#n2-ss-2 .n2-ss-button-container span {
			font-size: 100%;
			vertical-align: baseline;
		}

		div#n2-ss-2 .n2-ss-button-container a[data-iconplacement="left"] span {
			margin-right: 0.3em;
		}

		div#n2-ss-2 .n2-ss-button-container a[data-iconplacement="right"] span {
			margin-left: 0.3em;
		}

		div#n2-ss-2 .nextend-arrow {
			cursor: pointer;
			overflow: hidden;
			line-height: 0 !important;
			z-index: 18;
			-webkit-user-select: none;
		}

		div#n2-ss-2 .nextend-arrow img {
			position: relative;
			display: block;
		}

		div#n2-ss-2 .nextend-arrow img.n2-arrow-hover-img {
			display: none;
		}

		div#n2-ss-2 .nextend-arrow:FOCUS img.n2-arrow-hover-img,
		div#n2-ss-2 .nextend-arrow:HOVER img.n2-arrow-hover-img {
			display: inline;
		}

		div#n2-ss-2 .nextend-arrow:FOCUS img.n2-arrow-normal-img,
		div#n2-ss-2 .nextend-arrow:HOVER img.n2-arrow-normal-img {
			display: none;
		}

		div#n2-ss-2 .nextend-arrow-animated {
			overflow: hidden;
		}

		div#n2-ss-2 .nextend-arrow-animated>div {
			position: relative;
		}

		div#n2-ss-2 .nextend-arrow-animated .n2-active {
			position: absolute;
		}

		div#n2-ss-2 .nextend-arrow-animated-fade {
			transition: background 0.3s, opacity 0.4s;
		}

		div#n2-ss-2 .nextend-arrow-animated-horizontal>div {
			transition: all 0.4s;
			transform: none;
		}

		div#n2-ss-2 .nextend-arrow-animated-horizontal .n2-active {
			top: 0;
		}

		div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-horizontal .n2-active {
			left: 100%;
		}

		div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-horizontal .n2-active {
			right: 100%;
		}

		div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-horizontal:HOVER>div,
		div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-horizontal:FOCUS>div {
			transform: translateX(-100%);
		}

		div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-horizontal:HOVER>div,
		div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-horizontal:FOCUS>div {
			transform: translateX(100%);
		}

		div#n2-ss-2 .nextend-arrow-animated-vertical>div {
			transition: all 0.4s;
			transform: none;
		}

		div#n2-ss-2 .nextend-arrow-animated-vertical .n2-active {
			left: 0;
		}

		div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-vertical .n2-active {
			top: 100%;
		}

		div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-vertical .n2-active {
			bottom: 100%;
		}

		div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-vertical:HOVER>div,
		div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-vertical:FOCUS>div {
			transform: translateY(-100%);
		}

		div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-vertical:HOVER>div,
		div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-vertical:FOCUS>div {
			transform: translateY(100%);
		}

		div#n2-ss-2 .n2-ss-control-bullet {
			visibility: hidden;
			text-align: center;
			justify-content: center;
			z-index: 14;
		}

		div#n2-ss-2 .n2-ss-control-bullet--calculate-size {
			left: 0 !important;
		}

		div#n2-ss-2 .n2-ss-control-bullet-horizontal.n2-ss-control-bullet-fullsize {
			width: 100%;
		}

		div#n2-ss-2 .n2-ss-control-bullet-vertical.n2-ss-control-bullet-fullsize {
			height: 100%;
			flex-flow: column;
		}

		div#n2-ss-2 .nextend-bullet-bar {
			display: inline-flex;
			vertical-align: top;
			visibility: visible;
			align-items: center;
			flex-wrap: wrap;
		}

		div#n2-ss-2 .n2-bar-justify-content-left {
			justify-content: flex-start;
		}

		div#n2-ss-2 .n2-bar-justify-content-center {
			justify-content: center;
		}

		div#n2-ss-2 .n2-bar-justify-content-right {
			justify-content: flex-end;
		}

		div#n2-ss-2 .n2-ss-control-bullet-vertical>.nextend-bullet-bar {
			flex-flow: column;
		}

		div#n2-ss-2 .n2-ss-control-bullet-fullsize>.nextend-bullet-bar {
			display: flex;
		}

		div#n2-ss-2 .n2-ss-control-bullet-horizontal.n2-ss-control-bullet-fullsize>.nextend-bullet-bar {
			flex: 1 1 auto;
		}

		div#n2-ss-2 .n2-ss-control-bullet-vertical.n2-ss-control-bullet-fullsize>.nextend-bullet-bar {
			height: 100%;
		}

		div#n2-ss-2 .nextend-bullet-bar .n2-bullet {
			cursor: pointer;
			transition: background-color 0.4s;
		}

		div#n2-ss-2 .nextend-bullet-bar .n2-bullet.n2-active {
			cursor: default;
		}

		div#n2-ss-2 div.n2-ss-bullet-thumbnail-container {
			position: absolute;
			z-index: 10000000;
		}

		div#n2-ss-2 .n2-ss-bullet-thumbnail-container .n2-ss-bullet-thumbnail {
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center;
		}

		div#n2-ss-2 .n2-font-7b62b381999ed298f1cea0131406ce6e-hover {
			font-family: 'Playfair Display', 'Arial';
			color: #1a1a1a;
			font-size: 225%;
			text-shadow: none;
			line-height: 1.3;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 400;
		}

		div#n2-ss-2 .n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph {
			font-family: 'Playfair Display', 'Arial';
			color: #e79d19;
			font-size: 175%;
			text-shadow: none;
			line-height: 1.8;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 600;
		}

		div#n2-ss-2 .n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph a,
		div#n2-ss-2 .n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph a:FOCUS {
			font-family: 'Playfair Display', 'Arial';
			color: #16b7cc;
			font-size: 100%;
			text-shadow: none;
			line-height: 1.8;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 600;
		}

		div#n2-ss-2 .n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph a:HOVER,
		div#n2-ss-2 .n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph a:ACTIVE {
			font-family: 'Playfair Display', 'Arial';
			color: #16b7cc;
			font-size: 100%;
			text-shadow: none;
			line-height: 1.8;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 600;
		}

		div#n2-ss-2 .n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph {
			font-family: 'Playfair Display', 'Arial';
			color: #000000;
			font-size: 175%;
			text-shadow: none;
			line-height: 1.8;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 400;
		}

		div#n2-ss-2 .n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph a,
		div#n2-ss-2 .n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph a:FOCUS {
			font-family: 'Playfair Display', 'Arial';
			color: #16b7cc;
			font-size: 100%;
			text-shadow: none;
			line-height: 1.8;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 400;
		}

		div#n2-ss-2 .n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph a:HOVER,
		div#n2-ss-2 .n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph a:ACTIVE {
			font-family: 'Playfair Display', 'Arial';
			color: #16b7cc;
			font-size: 100%;
			text-shadow: none;
			line-height: 1.8;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: inherit;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 400;
		}

		div#n2-ss-2 .n2-font-bfef000707cb7c40da2168efc87afdb3-link a {
			font-family: 'Playfair Display', 'Arial';
			color: #ffffff;
			font-size: 137.5%;
			text-shadow: none;
			line-height: 1.5;
			font-weight: normal;
			font-style: normal;
			text-decoration: none;
			text-align: center;
			letter-spacing: normal;
			word-spacing: normal;
			text-transform: none;
			font-weight: 400;
		}

		div#n2-ss-2 .n2-style-60fbb869d9e0eaba1a6b91e353199fce-heading {
			background: #e79d19;
			opacity: 1;
			padding: 10px 30px 10px 30px;
			box-shadow: none;
			border: 0px solid RGBA(0, 0, 0, 1);
			border-radius: 0px;
		}

		div#n2-ss-2 .n-uc-1a47f583b6518-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-1a47f583b6518-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-1184211c73f1e-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-1184211c73f1e-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-1a18f991da5ea-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-1a18f991da5ea-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-oeT0amV4SWRv-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-oeT0amV4SWRv-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-kbop8W9NLReJ-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-kbop8W9NLReJ-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-nNuNzU5b2aey-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-nNuNzU5b2aey-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-wjaIUHm9rckV-inner {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n-uc-wjaIUHm9rckV-inner:HOVER {
			border-width: 0px 0px 0px 0px;
			border-style: solid;
			border-color: RGBA(255, 255, 255, 1);
		}

		div#n2-ss-2 .n2-style-4f72beb15bfb0511e07bfb33dde48a42-dot {
			background: RGBA(0, 0, 0, 0.57);
			opacity: 1;
			padding: 5px 5px 5px 5px;
			box-shadow: none;
			border: 0px solid RGBA(0, 0, 0, 1);
			border-radius: 50px;
			margin: 6px 5px;
		}

		div#n2-ss-2 .n2-style-4f72beb15bfb0511e07bfb33dde48a42-dot.n2-active,
		div#n2-ss-2 .n2-style-4f72beb15bfb0511e07bfb33dde48a42-dot:HOVER,
		div#n2-ss-2 .n2-style-4f72beb15bfb0511e07bfb33dde48a42-dot:FOCUS {
			background: #16b7cc;
		}

		div#n2-ss-2 .n2-style-52a3032cdf5e0a73159365f609201a73-simple {
			background: #ffffff;
			opacity: 1;
			padding: 5px 10px 5px 10px;
			box-shadow: 0px 0px 10px 0px RGBA(0, 0, 0, 0.16);
			border: 0px solid RGBA(0, 0, 0, 1);
			border-radius: 99px;
		}

		div#n2-ss-2 .n-uc-i9Q3PPctbcPo {
			padding: 0px 0px 0px 0px
		}

		div#n2-ss-2 .n-uc-1c6c49c96a8d6-inner {
			padding: 10px 10px 10px 0px;
			text-align: left;
			--ssselfalign: var(--ss-fs);
			;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-1c6c49c96a8d6 {
			align-self: var(--ss-fs);
		}

		div#n2-ss-2 .n-uc-mG2k8HLSPV4a-inner {
			padding: 45px 30px 35px 50px
		}

		div#n2-ss-2 .n-uc-mG2k8HLSPV4a-inner>.n2-ss-layer-row-inner {
			width: calc(100% + 21px);
			margin: -10px;
			flex-wrap: nowrap;
		}

		div#n2-ss-2 .n-uc-mG2k8HLSPV4a-inner>.n2-ss-layer-row-inner>.n2-ss-layer[data-sstype="col"] {
			margin: 10px
		}

		div#n2-ss-2 .n-uc-mG2k8HLSPV4a {
			max-width: 450px
		}

		div#n2-ss-2 .n-uc-153023fc3458e-inner {
			padding: 10px 10px 10px 10px;
			justify-content: flex-start
		}

		div#n2-ss-2 .n-uc-153023fc3458e {
			width: 100%
		}

		div#n2-ss-2 .n-uc-A3iho7WnCNLp {
			--margin-bottom: 20px
		}

		div#n2-ss-2 .n-uc-aK32FAB0sODG {
			--margin-top: 20px;
			--margin-bottom: 25px
		}

		div#n2-ss-2 .n-uc-1a47f583b6518-inner {
			padding: 10px 10px 10px 10px
		}

		div#n2-ss-2 .n-uc-1a47f583b6518-inner>.n2-ss-layer-row-inner {
			width: calc(100% + 21px);
			margin: -10px;
			flex-wrap: nowrap;
		}

		div#n2-ss-2 .n-uc-1a47f583b6518-inner>.n2-ss-layer-row-inner>.n2-ss-layer[data-sstype="col"] {
			margin: 10px
		}

		div#n2-ss-2 .n-uc-1184211c73f1e-inner {
			padding: 10px 10px 10px 10px;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-1184211c73f1e {
			width: 50%
		}

		div#n2-ss-2 .n-uc-1a18f991da5ea-inner {
			padding: 10px 10px 10px 10px;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-1a18f991da5ea {
			width: 50%
		}

		div#n2-ss-2 .n-uc-QAr9wwBP8aPl {
			padding: 20px 70px 60px 70px
		}

		div#n2-ss-2 .n-uc-zOrbtQPjM20v-inner {
			padding: 10px 10px 10px 10px;
			text-align: left;
			--ssselfalign: var(--ss-fs);
			;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-zOrbtQPjM20v {
			align-self: var(--ss-fs);
		}

		div#n2-ss-2 .n-uc-VWVpoH4jNgJN-inner {
			padding: 35px 30px 35px 30px
		}

		div#n2-ss-2 .n-uc-VWVpoH4jNgJN-inner>.n2-ss-layer-row-inner {
			width: calc(100% + 21px);
			margin: -10px;
			flex-wrap: nowrap;
		}

		div#n2-ss-2 .n-uc-VWVpoH4jNgJN-inner>.n2-ss-layer-row-inner>.n2-ss-layer[data-sstype="col"] {
			margin: 10px
		}

		div#n2-ss-2 .n-uc-VWVpoH4jNgJN {
			max-width: 450px
		}

		div#n2-ss-2 .n-uc-iM4EIg5p5Abj-inner {
			padding: 10px 10px 10px 10px;
			justify-content: flex-start
		}

		div#n2-ss-2 .n-uc-iM4EIg5p5Abj {
			width: 100%
		}

		div#n2-ss-2 .n-uc-mbM61XV3rqut {
			--margin-bottom: 20px
		}

		div#n2-ss-2 .n-uc-ueie0RmHTgAg {
			--margin-top: 20px;
			--margin-bottom: 25px
		}

		div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner {
			padding: 10px 10px 10px 10px
		}

		div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner>.n2-ss-layer-row-inner {
			width: calc(100% + 21px);
			margin: -10px;
			flex-wrap: nowrap;
		}

		div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner>.n2-ss-layer-row-inner>.n2-ss-layer[data-sstype="col"] {
			margin: 10px
		}

		div#n2-ss-2 .n-uc-oeT0amV4SWRv-inner {
			padding: 10px 10px 10px 10px;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-oeT0amV4SWRv {
			width: 50%
		}

		div#n2-ss-2 .n-uc-kbop8W9NLReJ-inner {
			padding: 10px 10px 10px 10px;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-kbop8W9NLReJ {
			width: 50%
		}

		div#n2-ss-2 .n-uc-qjWZY7C7aubM {
			padding: 20px 70px 60px 70px
		}

		div#n2-ss-2 .n-uc-ZiNaqUyfMxXy-inner {
			padding: 10px 10px 10px 10px;
			text-align: left;
			--ssselfalign: var(--ss-fs);
			;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-ZiNaqUyfMxXy {
			align-self: var(--ss-fs);
		}

		div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner {
			padding: 10px 10px 10px 10px
		}

		div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner>.n2-ss-layer-row-inner {
			width: calc(100% + 21px);
			margin: -10px;
			flex-wrap: nowrap;
		}

		div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner>.n2-ss-layer-row-inner>.n2-ss-layer[data-sstype="col"] {
			margin: 10px
		}

		div#n2-ss-2 .n-uc-nNuNzU5b2aey-inner {
			padding: 10px 10px 10px 10px;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-nNuNzU5b2aey {
			width: 50%
		}

		div#n2-ss-2 .n-uc-wjaIUHm9rckV-inner {
			padding: 10px 10px 10px 10px;
			justify-content: center
		}

		div#n2-ss-2 .n-uc-wjaIUHm9rckV {
			width: 50%
		}

		div#n2-ss-2 .nextend-arrow img {
			width: 32px
		}

		@media (min-width: 1200px) {
			div#n2-ss-2 [data-hide-desktopportrait="1"] {
				display: none !important;
			}
		}

		@media (orientation: landscape) and (max-width: 1199px) and (min-width: 901px),
		(orientation: portrait) and (max-width: 1199px) and (min-width: 701px) {
			div#n2-ss-2 .n-uc-i9Q3PPctbcPo {
				padding: 20px 70px 60px 70px
			}

			div#n2-ss-2 .n-uc-1c6c49c96a8d6-inner {
				padding: 10px 10px 10px 10px
			}

			div#n2-ss-2 .n-uc-mG2k8HLSPV4a-inner>.n2-ss-layer-row-inner {
				flex-wrap: nowrap;
			}

			div#n2-ss-2 .n-uc-153023fc3458e {
				width: 100%
			}

			div#n2-ss-2 .n-uc-A3iho7WnCNLp {
				--ssfont-scale: 0.8
			}

			div#n2-ss-2 .n-uc-1a47f583b6518-inner>.n2-ss-layer-row-inner {
				flex-wrap: nowrap;
			}

			div#n2-ss-2 .n-uc-1184211c73f1e {
				width: 50%
			}

			div#n2-ss-2 .n-uc-1a18f991da5ea {
				width: 50%
			}

			div#n2-ss-2 .n-uc-QAr9wwBP8aPl {
				padding: 20px 70px 60px 70px
			}

			div#n2-ss-2 .n-uc-zOrbtQPjM20v-inner {
				padding: 10px 10px 10px 10px
			}

			div#n2-ss-2 .n-uc-VWVpoH4jNgJN-inner>.n2-ss-layer-row-inner {
				flex-wrap: nowrap;
			}

			div#n2-ss-2 .n-uc-iM4EIg5p5Abj {
				width: 100%
			}

			div#n2-ss-2 .n-uc-mbM61XV3rqut {
				--ssfont-scale: 0.8
			}

			div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner>.n2-ss-layer-row-inner {
				flex-wrap: nowrap;
			}

			div#n2-ss-2 .n-uc-oeT0amV4SWRv {
				width: 50%
			}

			div#n2-ss-2 .n-uc-kbop8W9NLReJ {
				width: 50%
			}

			div#n2-ss-2 .n-uc-qjWZY7C7aubM {
				padding: 20px 70px 60px 70px
			}

			div#n2-ss-2 .n-uc-ZiNaqUyfMxXy-inner {
				padding: 10px 10px 10px 10px
			}

			div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner>.n2-ss-layer-row-inner {
				flex-wrap: nowrap;
			}

			div#n2-ss-2 .n-uc-nNuNzU5b2aey {
				width: 50%
			}

			div#n2-ss-2 .n-uc-wjaIUHm9rckV {
				width: 50%
			}

			div#n2-ss-2 [data-hide-tabletportrait="1"] {
				display: none !important;
			}
		}

		@media (orientation: landscape) and (max-width: 900px),
		(orientation: portrait) and (max-width: 700px) {
			div#n2-ss-2 .n-uc-i9Q3PPctbcPo {
				padding: 20px 10px 60px 10px
			}

			div#n2-ss-2 .n-uc-1c6c49c96a8d6-inner {
				padding: 10px 10px 10px 10px
			}

			div#n2-ss-2 .n-uc-mG2k8HLSPV4a-inner {
				padding: 15px 10px 15px 10px
			}

			div#n2-ss-2 .n-uc-mG2k8HLSPV4a-inner>.n2-ss-layer-row-inner {
				flex-wrap: wrap;
			}

			div#n2-ss-2 .n-uc-153023fc3458e {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-A3iho7WnCNLp {
				--ssfont-scale: 0.6
			}

			div#n2-ss-2 .n-uc-aK32FAB0sODG {
				--ssfont-scale: 0.8
			}

			div#n2-ss-2 .n-uc-1a47f583b6518-inner>.n2-ss-layer-row-inner {
				flex-wrap: wrap;
			}

			div#n2-ss-2 .n-uc-1184211c73f1e {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-1a18f991da5ea {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-QAr9wwBP8aPl {
				padding: 20px 10px 60px 10px
			}

			div#n2-ss-2 .n-uc-zOrbtQPjM20v-inner {
				padding: 10px 10px 10px 10px
			}

			div#n2-ss-2 .n-uc-VWVpoH4jNgJN-inner {
				padding: 15px 10px 15px 10px
			}

			div#n2-ss-2 .n-uc-VWVpoH4jNgJN-inner>.n2-ss-layer-row-inner {
				flex-wrap: wrap;
			}

			div#n2-ss-2 .n-uc-iM4EIg5p5Abj {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-mbM61XV3rqut {
				--ssfont-scale: 0.6
			}

			div#n2-ss-2 .n-uc-ueie0RmHTgAg {
				--ssfont-scale: 0.8
			}

			div#n2-ss-2 .n-uc-oHtJlCe0KaYo-inner>.n2-ss-layer-row-inner {
				flex-wrap: wrap;
			}

			div#n2-ss-2 .n-uc-oeT0amV4SWRv {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-kbop8W9NLReJ {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-qjWZY7C7aubM {
				padding: 20px 10px 60px 10px
			}

			div#n2-ss-2 .n-uc-ZiNaqUyfMxXy-inner {
				padding: 10px 10px 10px 10px
			}

			div#n2-ss-2 .n-uc-wR8JSgluMmg7-inner>.n2-ss-layer-row-inner {
				flex-wrap: wrap;
			}

			div#n2-ss-2 .n-uc-nNuNzU5b2aey {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 .n-uc-wjaIUHm9rckV {
				width: calc(100% - 20px)
			}

			div#n2-ss-2 [data-hide-mobileportrait="1"] {
				display: none !important;
			}

			div#n2-ss-2 .nextend-arrow img {
				width: 16px
			}
		}
	</style>
	<script src='./js/navigation-view.min.js' id='wp-block-navigation-view-js'></script>
	<script src='./js/navigation-view-modal.min.js' id='wp-block-navigation-view-2-js'></script>
	<script src='./js/svg-support-vendor-DOMPurify-DOMPurify.min.js' id='bodhi-dompurify-library-js'></script>
	<script src='./js/jquery-jquery.min.js' id='jquery-core-js'></script>
	<script src='./js/jquery-jquery-migrate.min.js' id='jquery-migrate-js'></script>
	<script src='./js/svg-support-js-min-svgs-inline-min.js' id='bodhi_svg_inline-js'></script>
	<script id='bodhi_svg_inline-js-after'>
		cssTarget = "img.style-svg"; ForceInlineSVGActive = "false"; frontSanitizationEnabled = "on";
	</script>
	<link rel="https://api.w.org/" href="http://localhost/wordpress/wp-json/" />
	<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/wordpress/xmlrpc.php?rsd" />
	<link rel="wlwmanifest" type="application/wlwmanifest+xml"
		href="http://localhost/wordpress/wp-includes/wlwmanifest.xml" />
	<meta name="generator" content="WordPress 6.1.1" /> <!-- start Simple Custom CSS and JS -->
	<style>
		/* Add your CSS code here.    For example:  .example {      color: red;  }    For brushing up on your CSS knowledge, check out http://www.w3schools.com/css/css_syntax.asp    End of comment */
	</style> <!-- end Simple Custom CSS and JS --> <!-- start Simple Custom CSS and JS -->
	<style>
		/* Add your CSS code here.    For example:  .example {      color: red;  }    For brushing up on your CSS knowledge, check out http://www.w3schools.com/css/css_syntax.asp    End of comment */
	</style> <!-- end Simple Custom CSS and JS --> <!-- start Simple Custom CSS and JS -->
	<style>
		/* Add your CSS code here.    For example:  .example {      color: red;  }    For brushing up on your CSS knowledge, check out http://www.w3schools.com/css/css_syntax.asp    End of comment */
		.style-svg {
			fill: orange;
		}

		.svg-container {
			box-shadow: 3px 3px 0px 0px rgba(0, 0, 0, 0.36);
			-webkit-box-shadow: 3px 3px 0px 0px rgba(0, 0, 0, 0.36);
			-moz-box-shadow: 3px 3px 0px 0px rgba(0, 0, 0, 0.36);
		}

		.svg-container:hover {
			background-color: orange;
		}

		.svg-container:hover>.style-svg {
			fill: white;
		}
	</style> <!-- end Simple Custom CSS and JS -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href='https://fonts.googleapis.com/css2?display=swap&family=Be+Vietnam' rel='stylesheet'>
	<link rel="icon" href="./images/z4136971394301_e567c053a76d15bb3e2a89eb1545f0aa.png" sizes="32x32" />
	<link rel="icon" href="./images/z4136971394301_e567c053a76d15bb3e2a89eb1545f0aa.png" sizes="192x192" />
	<link rel="apple-touch-icon" href="./images/z4136971394301_e567c053a76d15bb3e2a89eb1545f0aa.png" />
	<meta name="msapplication-TileImage"
		content="http://localhost/wordpress/wp-content/uploads/2023/02/z4136971394301_e567c053a76d15bb3e2a89eb1545f0aa.png" />
	<style id="egf-frontend-styles" type="text/css">
		font-be {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		p {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		h1 {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		h2 {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		h3 {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		h4 {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		h5 {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}

		h6 {
			font-family: 'Be Vietnam', sans-serif;
			font-style: normal;
			font-weight: 400;
		}
	</style>
	<script>(function () { this._N2 = this._N2 || { _r: [], _d: [], r: function () { this._r.push(arguments) }, d: function () { this._d.push(arguments) } } }).call(window); !function (a) { a.indexOf("Safari") > 0 && -1 === a.indexOf("Chrome") && document.documentElement.style.setProperty("--ss-safari-fix-225962", "1px") }(navigator.userAgent);</script>
	<script src="./js/smart-slider-3-Public-SmartSlider3-Application-Frontend-Assets-dist-n2.min.js" defer
		async></script>
	<script src="./js/smart-slider-3-Public-SmartSlider3-Application-Frontend-Assets-dist-smartslider-frontend.min.js"
		defer async></script>
	<script src="./js/smart-slider-3-Public-SmartSlider3-Slider-SliderType-Simple-Assets-dist-ss-simple.min.js" defer
		async></script>
	<script src="./js/smart-slider-3-Public-SmartSlider3-Widget-Arrow-ArrowImage-Assets-dist-w-arrow-image.min.js" defer
		async></script>
	<script src="./js/smart-slider-3-Public-SmartSlider3-Widget-Bullet-Assets-dist-w-bullet.min.js" defer
		async></script>
	<script>_N2.r('documentReady', function () { _N2.r(["documentReady", "smartslider-frontend", "SmartSliderWidgetArrowImage", "SmartSliderWidgetBulletTransition", "ss-simple"], function () { new _N2.SmartSliderSimple('n2-ss-2', { "admin": false, "background.video.mobile": 1, "loadingTime": 2000, "alias": { "id": 0, "smoothScroll": 0, "slideSwitch": 0, "scroll": 1 }, "align": "normal", "isDelayed": 0, "responsive": { "mediaQueries": { "all": false, "desktopportrait": ["(min-width: 1200px)"], "tabletportrait": ["(orientation: landscape) and (max-width: 1199px) and (min-width: 901px)", "(orientation: portrait) and (max-width: 1199px) and (min-width: 701px)"], "mobileportrait": ["(orientation: landscape) and (max-width: 900px)", "(orientation: portrait) and (max-width: 700px)"] }, "base": { "slideOuterWidth": 1920, "slideOuterHeight": 900, "sliderWidth": 1920, "sliderHeight": 900, "slideWidth": 1920, "slideHeight": 900 }, "hideOn": { "desktopLandscape": false, "desktopPortrait": false, "tabletLandscape": false, "tabletPortrait": false, "mobileLandscape": false, "mobilePortrait": false }, "onResizeEnabled": true, "type": "fullwidth", "sliderHeightBasedOn": "real", "focusUser": 1, "focusEdge": "auto", "breakpoints": [{ "device": "tabletPortrait", "type": "max-screen-width", "portraitWidth": 1199, "landscapeWidth": 1199 }, { "device": "mobilePortrait", "type": "max-screen-width", "portraitWidth": 700, "landscapeWidth": 900 }], "enabledDevices": { "desktopLandscape": 0, "desktopPortrait": 1, "tabletLandscape": 0, "tabletPortrait": 1, "mobileLandscape": 0, "mobilePortrait": 1 }, "sizes": { "desktopPortrait": { "width": 1920, "height": 900, "max": 3000, "min": 1200 }, "tabletPortrait": { "width": 701, "height": 328, "customHeight": false, "max": 1199, "min": 701 }, "mobilePortrait": { "width": 320, "height": 150, "customHeight": false, "max": 900, "min": 320 } }, "overflowHiddenPage": 0, "focus": { "offsetTop": "#wpadminbar", "offsetBottom": "" } }, "controls": { "mousewheel": 0, "touch": "horizontal", "keyboard": 1, "blockCarouselInteraction": 1 }, "playWhenVisible": 1, "playWhenVisibleAt": 0.5, "lazyLoad": 0, "lazyLoadNeighbor": 0, "blockrightclick": 0, "maintainSession": 0, "autoplay": { "enabled": 0, "start": 1, "duration": 8000, "autoplayLoop": 1, "allowReStart": 0, "pause": { "click": 1, "mouse": "0", "mediaStarted": 1 }, "resume": { "click": 0, "mouse": "0", "mediaEnded": 1, "slidechanged": 0 }, "interval": 1, "intervalModifier": "loop", "intervalSlide": "current" }, "perspective": 1500, "layerMode": { "playOnce": 0, "playFirstLayer": 1, "mode": "skippable", "inAnimation": "mainInEnd" }, "bgAnimations": 0, "mainanimation": { "type": "horizontal", "duration": 800, "delay": 0, "ease": "easeOutQuad", "shiftedBackgroundAnimation": 0 }, "carousel": 1, "initCallbacks": function () { new _N2.SmartSliderWidgetArrowImage(this); new _N2.SmartSliderWidgetBulletTransition(this, { "area": 10, "dotClasses": "n2-style-4f72beb15bfb0511e07bfb33dde48a42-dot ", "mode": "", "action": "click" }) } }) }) });</script>
</head>

<body class="home blog wp-custom-logo wp-embed-responsive"> <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0"
		width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-dark-grayscale">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.49803921568627" />
					<fefuncg type="table" tablevalues="0 0.49803921568627" />
					<fefuncb type="table" tablevalues="0 0.49803921568627" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-grayscale">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 1" />
					<fefuncg type="table" tablevalues="0 1" />
					<fefuncb type="table" tablevalues="0 1" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-purple-yellow">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.54901960784314 0.98823529411765" />
					<fefuncg type="table" tablevalues="0 1" />
					<fefuncb type="table" tablevalues="0.71764705882353 0.25490196078431" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-blue-red">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 1" />
					<fefuncg type="table" tablevalues="0 0.27843137254902" />
					<fefuncb type="table" tablevalues="0.5921568627451 0.27843137254902" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-midnight">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0" />
					<fefuncg type="table" tablevalues="0 0.64705882352941" />
					<fefuncb type="table" tablevalues="0 1" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-magenta-yellow">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.78039215686275 1" />
					<fefuncg type="table" tablevalues="0 0.94901960784314" />
					<fefuncb type="table" tablevalues="0.35294117647059 0.47058823529412" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-purple-green">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.65098039215686 0.40392156862745" />
					<fefuncg type="table" tablevalues="0 1" />
					<fefuncb type="table" tablevalues="0.44705882352941 0.4" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-blue-orange">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.098039215686275 1" />
					<fefuncg type="table" tablevalues="0 0.66274509803922" />
					<fefuncb type="table" tablevalues="0.84705882352941 0.41960784313725" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-foreground-and-background">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 1" />
					<fefuncg type="table" tablevalues="0 1" />
					<fefuncb type="table" tablevalues="0 1" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-foreground-and-secondary">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 1" />
					<fefuncg type="table" tablevalues="0 0.88627450980392" />
					<fefuncb type="table" tablevalues="0 0.78039215686275" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-foreground-and-tertiary">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-primary-and-background">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.10196078431373 1" />
					<fefuncg type="table" tablevalues="0.27058823529412 1" />
					<fefuncb type="table" tablevalues="0.28235294117647 1" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-primary-and-secondary">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.10196078431373 1" />
					<fefuncg type="table" tablevalues="0.27058823529412 0.88627450980392" />
					<fefuncb type="table" tablevalues="0.28235294117647 0.78039215686275" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-primary-and-tertiary">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0.10196078431373 0.96470588235294" />
					<fefuncg type="table" tablevalues="0.27058823529412 0.96470588235294" />
					<fefuncb type="table" tablevalues="0.28235294117647 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg>
	<div class="wp-site-blocks">
		<header class="wp-block-template-part">
			<div class="is-content-justification-center is-layout-constrained wp-container-7 wp-elements-52ccb10a34611d4cd3707ed50c923d88 wp-block-group alignfull has-source-serif-pro-font-family has-background-color has-foreground-background-color has-text-color has-background has-link-color"
				style="padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)">
				<header class="alignwide wp-block-template-part">
					<div class="is-layout-constrained wp-block-group">
						<div class="is-content-justification-space-between is-layout-flex wp-container-5 wp-block-group alignwide"
							style="padding-top:0px;padding-bottom:0px">
							<div class="is-layout-flex wp-block-group">
								<div class="wp-block-site-logo"><a href="./index.html" class="custom-logo-link"
										rel="home" aria-current="page"><img loading="lazy" width="48" height="57"
											src="./images/2023-02-z4136971394301_e567c053a76d15bb3e2a89eb1545f0aa.png"
											class="custom-logo" alt="MCCANNASIA" decoding="async" /></a></div>
								<nav class="is-layout-flex has-small-font-size is-responsive wp-block-navigation has-small-font-size"
									aria-label="Header navigation"><button aria-haspopup="true" aria-label="Open menu"
										class="wp-block-navigation__responsive-container-open"
										data-micromodal-trigger="modal-1"><svg width="24" height="24"
											xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24" aria-hidden="true"
											focusable="false">
											<rect x="4" y="7.5" width="16" height="1.5" />
											<rect x="4" y="15" width="16" height="1.5" />
										</svg></button>
									<div class="wp-block-navigation__responsive-container" style="" id="modal-1">
										<div class="wp-block-navigation__responsive-close" tabindex="-1"
											data-micromodal-close>
											<div class="wp-block-navigation__responsive-dialog" aria-label="Menu">
												<button aria-label="Close menu" data-micromodal-close
													class="wp-block-navigation__responsive-container-close"><svg
														xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24"
														width="24" height="24" aria-hidden="true" focusable="false">
														<path
															d="M13 11.8l6.1-6.3-1-1-6.1 6.2-6.1-6.2-1 1 6.1 6.3-6.5 6.7 1 1 6.5-6.6 6.5 6.6 1-1z">
														</path>
													</svg></button>
												<div class="wp-block-navigation__responsive-container-content"
													id="modal-1-content">
													<ul class="wp-block-navigation__container">
														<li
															class="has-small-font-size wp-block-navigation-item has-child open-on-hover-click wp-block-navigation-submenu">
															<a class="wp-block-navigation-item__content"
																href="http://localhost/wordpress/5-2/">Publisher</a><button
																aria-label="Publisher submenu"
																class="wp-block-navigation__submenu-icon wp-block-navigation-submenu__toggle"
																aria-expanded="false"><svg
																	xmlns="http://www.w3.org/2000/svg" width="12"
																	height="12" viewbox="0 0 12 12" fill="none"
																	aria-hidden="true" focusable="false">
																	<path d="M1.50002 4L6.00002 8L10.5 4"
																		stroke-width="1.5"></path>
																</svg></button>
															<ul class="wp-block-navigation__submenu-container">
																<li
																	class="has-small-font-size wp-block-navigation-item wp-block-navigation-link">
																	<a class="wp-block-navigation-item__content"
																		href="http://H%E1%BB%87%20Sinh%20Th%C3%A1i%20Publisher"><span
																			class="wp-block-navigation-item__label">Hệ
																			Sinh Thái Publisher</span></a></li>
																<li
																	class="has-small-font-size wp-block-navigation-item wp-block-navigation-link">
																	<a class="wp-block-navigation-item__content"
																		href="http://Ch%C3%ADnh%20S%C3%A1ch%20Publisher"><span
																			class="wp-block-navigation-item__label">Chính
																			Sách Publisher</span></a></li>
															</ul>
														</li>
														<li
															class="has-small-font-size wp-block-navigation-item wp-block-navigation-link">
															<a class="wp-block-navigation-item__content"
																href="http://localhost/wordpress/5-2/"><span
																	class="wp-block-navigation-item__label">Advertiser</span></a>
														</li>
														<li
															class="has-small-font-size wp-block-navigation-item has-child open-on-hover-click wp-block-navigation-submenu">
															<a class="wp-block-navigation-item__content"
																href="http://V%E1%BB%81%20MCCANNASIA">Về
																MCCANNASIA</a><button aria-label="Về MCCANNASIA submenu"
																class="wp-block-navigation__submenu-icon wp-block-navigation-submenu__toggle"
																aria-expanded="false"><svg
																	xmlns="http://www.w3.org/2000/svg" width="12"
																	height="12" viewbox="0 0 12 12" fill="none"
																	aria-hidden="true" focusable="false">
																	<path d="M1.50002 4L6.00002 8L10.5 4"
																		stroke-width="1.5"></path>
																</svg></button>
															<ul class="wp-block-navigation__submenu-container">
																<li
																	class="has-small-font-size wp-block-navigation-item wp-block-navigation-link">
																	<a class="wp-block-navigation-item__content"
																		href="http://Gi%E1%BB%9Bi%20Thi%E1%BB%87u"><span
																			class="wp-block-navigation-item__label">Giới
																			Thiệu</span></a></li>
																<li
																	class="has-small-font-size wp-block-navigation-item wp-block-navigation-link">
																	<a class="wp-block-navigation-item__content"
																		href="http://Li%C3%AAn%20H%E1%BB%87"><span
																			class="wp-block-navigation-item__label">Liên
																			Hệ</span></a></li>
															</ul>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</nav>
							</div>
							<div class="is-layout-flex wp-block-buttons">
								<div class="wp-block-button is-style-outline"><a
                                    href="{{route('auth.register')}}" class="wp-block-button__link wp-element-button"
										style="border-radius:0px;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)">Đăng
										Ký</a></div>
								<div class="wp-block-button"><a href="{{route('auth.login')}}" class="wp-block-button__link wp-element-button"
										style="border-radius:0px;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)">Đăng
										Nhâp</a></div>
							</div>
						</div>
					</div>
				</header>
			</div>
		</header>
		<main class="is-layout-constrained wp-block-query">
			<ul class="is-layout-flow alignwide wp-block-post-template">
				<li
					class="wp-block-post post-1 post type-post status-publish format-standard hentry category-uncategorized">
					<div class="is-layout-constrained wp-block-group" style="border-radius:5px">
						<div class="wp-block-nextend-smartslider3">
							<div class="n2_clear"><ss3-force-full-width data-overflow-x="html"
									data-horizontal-selector="">
									<div class="n2-section-smartslider fitvidsignore  n2_clear" data-ssid="2"
										tabindex="0" role="region" aria-label="Slider">
										<div id="n2-ss-2-align" class="n2-ss-align">
											<div class="n2-padding">
												<div id="n2-ss-2" data-creator="Smart Slider 3"
													data-responsive="fullwidth"
													class="n2-ss-slider n2-ow n2-has-hover n2notransition">
													<div class="n2-ss-slider-wrapper-inside">
														<div class="n2-ss-slider-1 n2_ss__touch_element n2-ow">
															<div class="n2-ss-slider-2 n2-ow">
																<div class="n2-ss-slider-3 n2-ow">
																	<div class="n2-ss-slide-backgrounds n2-ow-all">
																		<div class="n2-ss-slide-background"
																			data-public-id="1" data-mode="center">
																			<div class="n2-ss-slide-background-image"
																				data-blur="0" data-opacity="100"
																				data-x="72" data-y="23" data-alt=""
																				data-title=""
																				style="--ss-o-pos-x:72%;--ss-o-pos-y:23%">
																				<picture class="skip-lazy"
																					data-skip-lazy="1"><img
																						src="./images/2023-02-ezgif.com-gif-maker-scaled-2.jpg"
																						alt="" title="" loading="lazy"
																						class="skip-lazy"
																						data-skip-lazy="1"></picture>
																			</div>
																			<div data-color="RGBA(255,255,255,0)"
																				style="background-color: RGBA(255,255,255,0);"
																				class="n2-ss-slide-background-color"
																				data-overlay="1"></div>
																		</div>
																		<div class="n2-ss-slide-background"
																			data-public-id="2" data-mode="fill">
																			<div class="n2-ss-slide-background-image"
																				data-blur="0" data-opacity="100"
																				data-x="50" data-y="50" data-alt=""
																				data-title="">
																				<picture class="skip-lazy"
																					data-skip-lazy="1"><img
																						src="./images/2023-02-banner-hero-min-1-1.png"
																						alt="" title="" loading="lazy"
																						class="skip-lazy"
																						data-skip-lazy="1"></picture>
																			</div>
																			<div data-color="RGBA(255,255,255,0)"
																				style="background-color: RGBA(255,255,255,0);"
																				class="n2-ss-slide-background-color">
																			</div>
																		</div>
																		<div class="n2-ss-slide-background"
																			data-public-id="3" data-mode="fill">
																			<div class="n2-ss-slide-background-image"
																				data-blur="0" data-opacity="100"
																				data-x="73" data-y="49" data-alt=""
																				data-title=""
																				style="--ss-o-pos-x:73%;--ss-o-pos-y:49%">
																				<picture class="skip-lazy"
																					data-skip-lazy="1"><img
																						src="./images/2023-02-referral-phien-ban-hau-hinh-8-1.jpg"
																						alt="" title="" loading="lazy"
																						class="skip-lazy"
																						data-skip-lazy="1"></picture>
																			</div>
																			<div data-color="RGBA(255,255,255,0)"
																				style="background-color: RGBA(255,255,255,0);"
																				class="n2-ss-slide-background-color">
																			</div>
																		</div>
																	</div>
																	<div class="n2-ss-slider-4 n2-ow"> <svg
																			xmlns="http://www.w3.org/2000/svg"
																			viewbox="0 0 1920 900"
																			data-related-device="desktopPortrait"
																			class="n2-ow n2-ss-preserve-size n2-ss-preserve-size--slider n2-ss-slide-limiter"></svg>
																		<div data-first="1" data-slide-duration="0"
																			data-id="3" data-slide-public-id="1"
																			data-title="Slide 1"
																			class="n2-ss-slide n2-ow  n2-ss-slide-3">
																			<div role="note" class="n2-ss-slide--focus"
																				tabindex="-1">Slide 1</div>
																			<div
																				class="n2-ss-layers-container n2-ss-slide-limiter n2-ow">
																				<div class="n2-ss-layer n2-ow n-uc-i9Q3PPctbcPo"
																					data-sstype="slide"
																					data-pm="default">
																					<div class="n2-ss-layer n2-ow n-uc-1c6c49c96a8d6"
																						style="overflow:hidden;"
																						data-pm="default"
																						data-sstype="content"
																						data-hasbackground="0">
																						<div
																							class="n2-ss-section-main-content n2-ss-layer-with-background n2-ss-layer-content n2-ow n-uc-1c6c49c96a8d6-inner">
																							<div class="n2-ss-layer n2-ow n2-ss-layer--block n2-ss-has-self-align n-uc-mG2k8HLSPV4a"
																								data-pm="normal"
																								data-sstype="row">
																								<div
																									class="n2-ss-layer-row n2-ss-layer-with-background n-uc-mG2k8HLSPV4a-inner">
																									<div
																										class="n2-ss-layer-row-inner">
																										<div class="n2-ss-layer n2-ow n-uc-153023fc3458e"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-153023fc3458e-inner">
																												<div class="n2-ss-layer n2-ow n-uc-A3iho7WnCNLp"
																													data-pm="normal"
																													data-sstype="layer">
																													<div id="n2-ss-2item1"
																														class="n2-font-7b62b381999ed298f1cea0131406ce6e-hover   n2-ss-item-content n2-ss-text n2-ow"
																														style="display:block;">
																														Thu
																														nhập
																														bền
																														vững
																														cùng
																													</div>
																												</div>
																												<div class="n2-ss-layer n2-ow n-uc-dav3ClPHaNoJ"
																													data-pm="normal"
																													data-sstype="layer">
																													<div
																														class="n2-ss-item-content n2-ss-text n2-ow-all">
																														<div
																															class="">
																															<p
																																class="n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph">
																																MCCANNASIA.COM
																															</p>
																														</div>
																													</div>
																												</div>
																												<div class="n2-ss-layer n2-ow n-uc-aK32FAB0sODG"
																													data-pm="normal"
																													data-sstype="layer">
																													<div
																														class="n2-ss-item-content n2-ss-text n2-ow-all">
																														<div
																															class="">
																															<p
																																class="n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph">
																																Hoa
																																Hồng
																																Của
																																Bạn
																																Là
																																Sứ
																																Mệnh
																																Của
																																Chúng
																																Tôi
																															</p>
																														</div>
																													</div>
																												</div>
																												<div class="n2-ss-layer n2-ow n-uc-ff1c2P4b1kfO n2-ss-layer--auto"
																													data-pm="normal"
																													data-sstype="layer">
																													<div
																														class="n2-ss-button-container n2-ss-item-content n2-ow n2-font-bfef000707cb7c40da2168efc87afdb3-link  n2-ss-nowrap n2-ss-button-container--non-full-width">
																														<a class="n2-style-60fbb869d9e0eaba1a6b91e353199fce-heading  n2-ow"
																															onclick="return false;"
																															href="#">
																															<div>
																																<div>
																																	Đăng
																																	Ký
																																	Ngay
																																</div>
																															</div>
																														</a>
																													</div>
																												</div>
																											</div>
																										</div>
																									</div>
																								</div>
																							</div>
																							<div class="n2-ss-layer n2-ow n2-ss-layer--block n2-ss-has-self-align n-uc-1a47f583b6518"
																								data-pm="normal"
																								data-sstype="row">
																								<div
																									class="n2-ss-layer-row n2-ss-layer-with-background n-uc-1a47f583b6518-inner">
																									<div
																										class="n2-ss-layer-row-inner">
																										<div class="n2-ss-layer n2-ow n-uc-1184211c73f1e"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-1184211c73f1e-inner">
																											</div>
																										</div>
																										<div class="n2-ss-layer n2-ow n-uc-1a18f991da5ea"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-1a18f991da5ea-inner">
																											</div>
																										</div>
																									</div>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div data-slide-duration="0" data-id="8"
																			data-slide-public-id="2"
																			data-title="Slide 1"
																			class="n2-ss-slide n2-ow  n2-ss-slide-8">
																			<div role="note" class="n2-ss-slide--focus"
																				tabindex="-1">Slide 1</div>
																			<div
																				class="n2-ss-layers-container n2-ss-slide-limiter n2-ow">
																				<div class="n2-ss-layer n2-ow n-uc-QAr9wwBP8aPl"
																					data-sstype="slide"
																					data-pm="default">
																					<div class="n2-ss-layer n2-ow n-uc-zOrbtQPjM20v"
																						data-pm="default"
																						data-sstype="content"
																						data-hasbackground="0">
																						<div
																							class="n2-ss-section-main-content n2-ss-layer-with-background n2-ss-layer-content n2-ow n-uc-zOrbtQPjM20v-inner">
																							<div class="n2-ss-layer n2-ow n2-ss-layer--block n2-ss-has-self-align n-uc-VWVpoH4jNgJN"
																								data-pm="normal"
																								data-sstype="row">
																								<div
																									class="n2-ss-layer-row n2-ss-layer-with-background n-uc-VWVpoH4jNgJN-inner">
																									<div
																										class="n2-ss-layer-row-inner">
																										<div class="n2-ss-layer n2-ow n-uc-iM4EIg5p5Abj"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-iM4EIg5p5Abj-inner">
																												<div class="n2-ss-layer n2-ow n-uc-mbM61XV3rqut"
																													data-pm="normal"
																													data-sstype="layer">
																													<div id="n2-ss-2item5"
																														class="n2-font-7b62b381999ed298f1cea0131406ce6e-hover   n2-ss-item-content n2-ss-text n2-ow"
																														style="display:block;">
																														Kết
																														Nối
																														Để
																														Thành
																														Công
																														Cùng
																													</div>
																												</div>
																												<div class="n2-ss-layer n2-ow n-uc-2eeG4eFo3aoY"
																													data-pm="normal"
																													data-sstype="layer">
																													<div
																														class="n2-ss-item-content n2-ss-text n2-ow-all">
																														<div
																															class="">
																															<p
																																class="n2-font-18e7a3912d5bc981dd7ffdaa419daba0-paragraph">
																																MCCANNASIA.COM
																															</p>
																														</div>
																													</div>
																												</div>
																												<div class="n2-ss-layer n2-ow n-uc-ueie0RmHTgAg"
																													data-pm="normal"
																													data-sstype="layer">
																													<div
																														class="n2-ss-item-content n2-ss-text n2-ow-all">
																														<div
																															class="">
																															<p
																																class="n2-font-83f11fc91d2990afdf4eb1fe48b8305f-paragraph">
																																Nền
																																Tảng
																																Tăng
																																Trưởng
																																Doanh
																																Thu
																																Hiệu
																																Quả
																																Hàng
																																Đầu
																																Việt
																																Nam
																																&amp;
																																SEASIA
																															</p>
																														</div>
																													</div>
																												</div>
																												<div class="n2-ss-layer n2-ow n-uc-BkDDF9LkWg92 n2-ss-layer--auto"
																													data-pm="normal"
																													data-sstype="layer">
																													<div
																														class="n2-ss-button-container n2-ss-item-content n2-ow n2-font-bfef000707cb7c40da2168efc87afdb3-link  n2-ss-nowrap n2-ss-button-container--non-full-width">
																														<a class="n2-style-60fbb869d9e0eaba1a6b91e353199fce-heading  n2-ow"
																															onclick="return false;"
																															href="#">
																															<div>
																																<div>
																																	Đăng
																																	Ký
																																	Ngay
																																</div>
																															</div>
																														</a>
																													</div>
																												</div>
																											</div>
																										</div>
																									</div>
																								</div>
																							</div>
																							<div class="n2-ss-layer n2-ow n2-ss-layer--block n2-ss-has-self-align n-uc-oHtJlCe0KaYo"
																								data-pm="normal"
																								data-sstype="row">
																								<div
																									class="n2-ss-layer-row n2-ss-layer-with-background n-uc-oHtJlCe0KaYo-inner">
																									<div
																										class="n2-ss-layer-row-inner">
																										<div class="n2-ss-layer n2-ow n-uc-oeT0amV4SWRv"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-oeT0amV4SWRv-inner">
																											</div>
																										</div>
																										<div class="n2-ss-layer n2-ow n-uc-kbop8W9NLReJ"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-kbop8W9NLReJ-inner">
																											</div>
																										</div>
																									</div>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																		<div data-slide-duration="0" data-id="9"
																			data-slide-public-id="3"
																			data-title="Slide 1"
																			class="n2-ss-slide n2-ow  n2-ss-slide-9">
																			<div role="note" class="n2-ss-slide--focus"
																				tabindex="-1">Slide 1</div>
																			<div
																				class="n2-ss-layers-container n2-ss-slide-limiter n2-ow">
																				<div class="n2-ss-layer n2-ow n-uc-qjWZY7C7aubM"
																					data-sstype="slide"
																					data-pm="default">
																					<div class="n2-ss-layer n2-ow n-uc-ZiNaqUyfMxXy"
																						data-pm="default"
																						data-sstype="content"
																						data-hasbackground="0">
																						<div
																							class="n2-ss-section-main-content n2-ss-layer-with-background n2-ss-layer-content n2-ow n-uc-ZiNaqUyfMxXy-inner">
																							<div class="n2-ss-layer n2-ow n2-ss-layer--block n2-ss-has-self-align n-uc-wR8JSgluMmg7"
																								data-pm="normal"
																								data-sstype="row">
																								<div
																									class="n2-ss-layer-row n2-ss-layer-with-background n-uc-wR8JSgluMmg7-inner">
																									<div
																										class="n2-ss-layer-row-inner">
																										<div class="n2-ss-layer n2-ow n-uc-nNuNzU5b2aey"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-nNuNzU5b2aey-inner">
																											</div>
																										</div>
																										<div class="n2-ss-layer n2-ow n-uc-wjaIUHm9rckV"
																											data-pm="default"
																											data-sstype="col">
																											<div
																												class="n2-ss-layer-col n2-ss-layer-with-background n2-ss-layer-content n-uc-wjaIUHm9rckV-inner">
																											</div>
																										</div>
																									</div>
																								</div>
																							</div>
																							<div class="n2-ss-layer n2-ow n-uc-1377c8717ae24 n2-ss-layer--auto"
																								data-pm="normal"
																								data-sstype="layer">
																								<div
																									class="n2-ss-button-container n2-ss-item-content n2-ow n2-font-bfef000707cb7c40da2168efc87afdb3-link  n2-ss-nowrap n2-ss-button-container--non-full-width">
																									<a class="n2-style-60fbb869d9e0eaba1a6b91e353199fce-heading  n2-ow"
																										onclick="return false;"
																										href="#">
																										<div>
																											<div>Đăng Ký
																												Ngay
																											</div>
																										</div>
																									</a></div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<div
															class="n2-ss-slider-controls n2-ss-slider-controls-absolute-left-center">
															<div style="--widget-offset:15px;"
																class="n2-ss-widget nextend-arrow n2-ow-all nextend-arrow-previous  nextend-arrow-animated-fade"
																data-hide-mobileportrait="1" id="n2-ss-2-arrow-previous"
																role="button" aria-label="previous arrow" tabindex="0">
																<img width="32" height="32" class="skip-lazy"
																	data-skip-lazy="1"
																	src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxwYXRoIGQ9Ik0xMS40MzMgMTUuOTkyTDIyLjY5IDUuNzEyYy4zOTMtLjM5LjM5My0xLjAzIDAtMS40Mi0uMzkzLS4zOS0xLjAzLS4zOS0xLjQyMyAwbC0xMS45OCAxMC45NGMtLjIxLjIxLS4zLjQ5LS4yODUuNzYtLjAxNS4yOC4wNzUuNTYuMjg0Ljc3bDExLjk4IDEwLjk0Yy4zOTMuMzkgMS4wMy4zOSAxLjQyNCAwIC4zOTMtLjQuMzkzLTEuMDMgMC0xLjQybC0xMS4yNTctMTAuMjkiCiAgICAgICAgICBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjgiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPgo8L3N2Zz4="
																	alt="previous arrow"></div>
														</div>
														<div
															class="n2-ss-slider-controls n2-ss-slider-controls-absolute-right-center">
															<div style="--widget-offset:15px;"
																class="n2-ss-widget nextend-arrow n2-ow-all nextend-arrow-next  nextend-arrow-animated-fade"
																data-hide-mobileportrait="1" id="n2-ss-2-arrow-next"
																role="button" aria-label="next arrow" tabindex="0"><img
																	width="32" height="32" class="skip-lazy"
																	data-skip-lazy="1"
																	src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxwYXRoIGQ9Ik0xMC43MjIgNC4yOTNjLS4zOTQtLjM5LTEuMDMyLS4zOS0xLjQyNyAwLS4zOTMuMzktLjM5MyAxLjAzIDAgMS40MmwxMS4yODMgMTAuMjgtMTEuMjgzIDEwLjI5Yy0uMzkzLjM5LS4zOTMgMS4wMiAwIDEuNDIuMzk1LjM5IDEuMDMzLjM5IDEuNDI3IDBsMTIuMDA3LTEwLjk0Yy4yMS0uMjEuMy0uNDkuMjg0LS43Ny4wMTQtLjI3LS4wNzYtLjU1LS4yODYtLjc2TDEwLjcyIDQuMjkzeiIKICAgICAgICAgIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuOCIgZmlsbC1ydWxlPSJldmVub2RkIi8+Cjwvc3ZnPg=="
																	alt="next arrow"></div>
														</div>
														<div
															class="n2-ss-slider-controls n2-ss-slider-controls-absolute-center-bottom">
															<div style="--widget-offset:10px;"
																class="n2-ss-widget n2-ss-control-bullet n2-ow-all n2-ss-control-bullet-horizontal">
																<div
																	class="n2-style-52a3032cdf5e0a73159365f609201a73-simple  nextend-bullet-bar n2-bar-justify-content-center">
																	<div class="n2-bullet n2-style-4f72beb15bfb0511e07bfb33dde48a42-dot"
																		style="visibility:hidden;"></div>
																</div>
															</div>
														</div>
													</div>
												</div><ss3-loader></ss3-loader>
											</div>
										</div>
										<div class="n2_clear"></div>
									</div>
								</ss3-force-full-width></div>
						</div>
						<h3 class="has-text-align-center"><strong>HỆ SINH THÁI MCCANNASIA</strong></h3>
						<h5 class="has-text-align-center"><strong>Tăng trưởng cho&nbsp;<span
									style="color:orange">Advertiser</span>&nbsp;&#8211; Thu nhập cho&nbsp;<span
									style="color:orange">Publisher</span></strong></h5>
						<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
								loading="lazy"
								src="./images/2023-02-imgpsh_fullsize_anim-1-e1623508623688-1024x583-min.png" alt=""
								class="wp-image-87" width="840" height="478" /></figure>
						<div style="height:112px" aria-hidden="true" class="wp-block-spacer"></div>
					</div>
				</li>
			</ul>
		</main>
		<div class="is-layout-flow wp-block-group has-border-color has-pale-cyan-blue-border-color"
			style="border-width:1px;border-radius:10px">
			<div class="is-layout-flex wp-container-23 wp-block-columns"
				style="border-style:none;border-width:0px;border-radius:0px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
				<div class="is-layout-flow wp-block-column">
					<h4 class="has-large-font-size">Dành cho Cộng Tác Viên (Publisher)</h4>
					<h5>Thu nhập của bạn &#8211; Sứ mệnh chúng tôi</h5>
					<ul>
						<li>Thu nhập lên đến 50 triệu/tháng</li>
						<li>Tự do&nbsp;<em><a href="https://accesstrade.vn//kiem-tien-online.html">kiếm tiền
									online</a></em>&nbsp;mọi lúc, mọi nơi</li>
						<li><strong>Được đào tạo miễn phí từ&nbsp;<a href="https://academy.accesstrade.vn/"
									target="_blank" rel="noreferrer noopener">Học Viện ACCESSTRADE Academy</a></strong>
						</li>
					</ul>
					<p><em>*<u>Đặc biệt</u>: Hướng dẫn&nbsp;</em><a rel="noreferrer noopener"
							href="https://dangky.accesstrade.vn/hoahong" target="_blank">kiếm ngay 1 triệu đầu
							tiên</a><em>&nbsp;cực dễ&nbsp;</em></p>
					<div class="is-layout-flex wp-block-buttons">
						<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">KIẾM TIỀN
								NGAY</a></div>
					</div>
					<ul>
						<li></li>
					</ul>
				</div>
				<div class="is-layout-flow wp-block-column">
					<div class="is-nowrap is-layout-flex wp-container-15 wp-block-group">
						<figure class="wp-block-image size-full is-resized"><img decoding="async" loading="lazy"
								src="./images/2023-02-affliliate.png" alt="" class="wp-image-94" width="60"
								height="60" /></figure>
						<div class="is-layout-flex wp-container-14 wp-block-columns">
							<div class="is-layout-flow wp-block-column">
								<h4>ACCESS AFFILIATE</h4>
								<p>Nền tảng kiếm tiền online bằng Affiliate Marketing hàng đầu Vietnam &amp; SEASIA</p>
							</div>
						</div>
					</div>
					<div class="is-nowrap is-layout-flex wp-container-18 wp-block-group">
						<figure class="wp-block-image size-full is-resized"><img decoding="async" loading="lazy"
								src="./images/2023-02-d2c__1_-removebg-preview.png" alt="" class="wp-image-98"
								width="60" height="60" /></figure>
						<div class="is-layout-flex wp-container-17 wp-block-columns">
							<div class="is-layout-flow wp-block-column">
								<h4>ACCESS D2C</h4>
								<p>Nền tảng kiếm tiền online với sản phẩm chính hãng. Hoa hồng lên đến 45%</p>
							</div>
						</div>
					</div>
					<div class="is-nowrap is-layout-flex wp-container-21 wp-block-group">
						<figure class="wp-block-image size-full is-resized"><img decoding="async" loading="lazy"
								src="./images/2023-02-koc__1_-removebg-preview.png" alt="" class="wp-image-99"
								width="60" height="60" /></figure>
						<div class="is-layout-flex wp-container-20 wp-block-columns">
							<div class="is-layout-flow wp-block-column">
								<h4>ACCESS KOC</h4>
								<p>Nền tảng tăng thu nhập uy tín cho KOLs &amp; Influencers</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<h4 class="has-text-align-center"><strong>Vì Sao Nên Chọn MCCANNASIA</strong></h4>
		<div class="is-layout-flex wp-container-57 wp-block-columns"
			style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
			<div class="is-layout-flow wp-block-column"
				style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-block-group">
						<div class="is-layout-constrained wp-container-26 wp-block-group svg-container has-small-font-size"
							style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
							<figure
								class="wp-duotone-000000-f6f6f6-25 wp-block-image alignfull size-full has-custom-border is-style-default style-svg">
								<img decoding="async" src="./images/2023-02-1-1.svg" alt="" class="wp-image-139"
									style="border-style:none;border-width:0px" /></figure>
						</div>
						<p
							class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
							<strong>21+</strong></p>
						<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Năm kinh nghiệm<br>
						</p>
					</div>
				</div>
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-container-30 wp-block-group svg-container has-small-font-size"
						style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
						<figure
							class="wp-duotone-000000-f6f6f6-29 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
							<img decoding="async" src="./images/2023-02-4.svg" alt="" class="wp-image-156"
								style="border-style:none;border-width:0px" /></figure>
					</div>
					<p
						class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
						<strong>95+</strong></p>
					<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Triệu click/ tháng</p>
				</div>
			</div>
			<div class="is-layout-flow wp-block-column">
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-block-group">
						<div class="is-layout-constrained wp-container-34 wp-block-group svg-container has-small-font-size"
							style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
							<figure
								class="wp-duotone-000000-f6f6f6-33 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
								<img decoding="async" src="./images/2023-02-2-1.svg" alt="" class="wp-image-153"
									style="border-style:none;border-width:0px" /></figure>
						</div>
						<p
							class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
							<strong>1.500.000+</strong></p>
						<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Publisher trên toàn
							quốc</p>
					</div>
				</div>
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-container-38 wp-block-group svg-container has-small-font-size"
						style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
						<figure
							class="wp-duotone-000000-f6f6f6-37 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
							<img decoding="async" src="./images/2023-02-5.svg" alt="" class="wp-image-157"
								style="border-style:none;border-width:0px" /></figure>
					</div>
					<p
						class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
						<strong>6500+</strong></p>
					<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Leads chất lượng/ tháng
					</p>
				</div>
			</div>
			<div class="is-layout-flow wp-block-column">
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-block-group">
						<div class="is-layout-constrained wp-container-42 wp-block-group svg-container has-small-font-size"
							style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
							<figure
								class="wp-duotone-000000-f6f6f6-41 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
								<img decoding="async" src="./images/2023-02-3.svg" alt="" class="wp-image-154"
									style="border-style:none;border-width:0px" /></figure>
						</div>
						<p
							class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
							<strong>1000+</strong></p>
						<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Thương hiệu lớn tin
							chọn</p>
					</div>
				</div>
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-container-46 wp-block-group svg-container has-small-font-size"
						style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
						<figure
							class="wp-duotone-000000-f6f6f6-45 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
							<img decoding="async" src="./images/2023-02-6-1.svg" alt="" class="wp-image-158"
								style="border-style:none;border-width:0px" /></figure>
					</div>
					<p
						class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
						<strong>6</strong></p>
					<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Quốc gia đã có mặt</p>
				</div>
			</div>
			<div class="is-layout-flow wp-block-column">
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-block-group">
						<div class="is-layout-constrained wp-container-50 wp-block-group svg-container has-small-font-size"
							style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
							<figure
								class="wp-duotone-000000-f6f6f6-49 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
								<img decoding="async" src="./images/2023-02-atlassian.svg" alt="" class="wp-image-155"
									style="border-style:none;border-width:0px" /></figure>
						</div>
						<p
							class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
							No.1</p>
						<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Quy mô &amp; Uy tín
							nhất VN</p>
					</div>
				</div>
				<div class="is-layout-constrained wp-block-group">
					<div class="is-layout-constrained wp-container-54 wp-block-group svg-container has-small-font-size"
						style="border-style:none;border-width:0px;border-radius:9999px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
						<figure
							class="wp-duotone-000000-f6f6f6-53 wp-block-image alignfull size-large has-custom-border is-style-default style-svg">
							<img decoding="async" src="./images/2023-02-7-2.svg" alt="" class="wp-image-166"
								style="border-style:none;border-width:0px" /></figure>
					</div>
					<p
						class="has-text-align-center has-luminous-vivid-amber-color has-text-color has-x-large-font-size">
						<strong>100%</strong></p>
					<p class="has-text-align-center has-cyan-bluish-gray-color has-text-color">Cải thiện doanh số</p>
				</div>
			</div>
		</div>
		<h4 class="has-text-align-center"><strong>Được Tin Tưởng Bởi<br>Hơn <span style="color:orange">1.000 Nhãn
					Hàng</span> Thuộc Đa Lĩnh Vực</strong></h4>
		<div class="is-layout-flow wp-block-query">
			<ul class="is-layout-flow wp-block-post-template">
				<li
					class="wp-block-post post-1 post type-post status-publish format-standard hentry category-uncategorized">
					<div class="is-layout-flex wp-container-70 wp-block-columns">
						<div class="is-layout-flow wp-block-column">
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-skincare-1.jpg" alt="" class="wp-image-188"
										width="120" height="120" /></figure>
								<p class="has-text-align-center">Mỹ phẩm</p>
							</div>
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-education-1.jpg" alt=""
										class="wp-image-191" width="120" height="120" /></figure>
								<p class="has-text-align-center">Giáo dục</p>
							</div>
						</div>
						<div class="is-layout-flow wp-block-column">
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-medicine-1.jpg" alt="" class="wp-image-187"
										width="120" height="120" /></figure>
								<p class="has-text-align-center">Dược phẩm</p>
							</div>
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-around-1.jpg" alt="" class="wp-image-192"
										width="120" height="120" /></figure>
								<p class="has-text-align-center">Du lịch</p>
							</div>
						</div>
						<div class="is-layout-flow wp-block-column">
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-dress-1.jpg" alt="" class="wp-image-189"
										width="120" height="120" /></figure>
								<p class="has-text-align-center">Thời trang</p>
							</div>
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-bank-1.jpg" alt="" class="wp-image-193"
										width="120" height="120" /></figure>
								<p class="has-text-align-center">Ngân hàng</p>
							</div>
						</div>
						<div class="is-layout-flow wp-block-column">
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-electronics-1.jpg" alt=""
										class="wp-image-190" width="120" height="120" /></figure>
								<p class="has-text-align-center">Điện tử</p>
							</div>
							<div class="is-layout-constrained wp-block-group">
								<figure class="wp-block-image aligncenter size-full is-resized"><img decoding="async"
										loading="lazy" src="./images/2023-02-online-shopping-1.jpg" alt=""
										class="wp-image-194" width="120" height="120" /></figure>
								<p class="has-text-align-center">Thương mại điện tử</p>
							</div>
						</div>
					</div>
				</li>
			</ul>
			<h3 class="has-text-align-center"><strong>Thông Tin Cập Nhật</strong></h3>
		</div>
		<footer class="wp-block-template-part">
			<div class="is-layout-flow wp-block-group has-foreground-background-color has-background"
				style="margin-top:0;margin-bottom:0;padding-top:var(--wp--custom--spacing--large, 8rem);padding-right:0;padding-bottom:0;padding-left:0">
				<div class="is-layout-flex wp-container-77 wp-block-columns alignwide"
					style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)">
					<div class="is-layout-flow wp-block-column">
						<figure class="wp-block-image size-full is-resized"><img decoding="async" loading="lazy"
								src="./images/2023-02-z4136971394301_e567c053a76d15bb3e2a89eb1545f0aa.png" alt=""
								class="wp-image-16" width="77" height="91" /></figure>
						<p class="has-background-color has-text-color">MCCANNASIA.COM</p>
					</div>
					<div class="is-layout-flow wp-block-column">
						<p class="has-luminous-vivid-amber-color has-text-color" style="text-decoration:underline">ĐỊA
							CHỈ</p>
						<p class="has-background-color has-text-color">SỐ 1 ĐƯỜNG HÀ NỘI</p>
					</div>
					<div class="is-layout-flow wp-block-column">
						<p class="has-luminous-vivid-amber-color has-text-color" style="text-decoration:underline">LIÊN
							HỆ</p>
						<p class="has-background-color has-text-color">SỐ 1 ĐƯỜNG HÀ NỘI</p>
					</div>
					<div class="is-layout-flow wp-block-column">
						<p class="has-luminous-vivid-amber-color has-text-color" style="text-decoration:underline">ĐIỀU
							KHOẢN SỬ DỤNG</p>
						<p class="has-background-color has-text-color">SỐ 1 ĐƯỜNG HÀ NỘI</p>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<style id="skip-link-styles">
		.skip-link.screen-reader-text {
			border: 0;
			clip: rect(1px, 1px, 1px, 1px);
			clip-path: inset(50%);
			height: 1px;
			margin: -1px;
			overflow: hidden;
			padding: 0;
			position: absolute !important;
			width: 1px;
			word-wrap: normal !important;
		}

		.skip-link.screen-reader-text:focus {
			background-color: #eee;
			clip: auto !important;
			clip-path: none;
			color: #444;
			display: block;
			font-size: 1em;
			height: auto;
			left: 5px;
			line-height: normal;
			padding: 15px 23px 14px;
			text-decoration: none;
			top: 5px;
			width: auto;
			z-index: 100000;
		}
	</style>
	<script>
		(function () {
			var skipLinkTarget = document.querySelector('main'),
				sibling,
				skipLinkTargetID,
				skipLink;

			// Early exit if a skip-link target can't be located.
			if (!skipLinkTarget) {
				return;
			}

			// Get the site wrapper.
			// The skip-link will be injected in the beginning of it.
			sibling = document.querySelector('.wp-site-blocks');

			// Early exit if the root element was not found.
			if (!sibling) {
				return;
			}

			// Get the skip-link target's ID, and generate one if it doesn't exist.
			skipLinkTargetID = skipLinkTarget.id;
			if (!skipLinkTargetID) {
				skipLinkTargetID = 'wp--skip-link--target';
				skipLinkTarget.id = skipLinkTargetID;
			}

			// Create the skip link.
			skipLink = document.createElement('a');
			skipLink.classList.add('skip-link', 'screen-reader-text');
			skipLink.href = '#' + skipLinkTargetID;
			skipLink.innerHTML = 'Skip to content';

			// Inject the skip link.
			sibling.parentElement.insertBefore(skipLink, sibling);
		}());
	</script> <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-25">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-29">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-33">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-37">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-41">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-45">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-49">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg><svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 0 0" width="0" height="0" focusable="false" role="none"
		style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
		<defs>
			<filter id="wp-duotone-000000-f6f6f6-53">
				<fecolormatrix color-interpolation-filters="sRGB" type="matrix"
					values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " />
				<fecomponenttransfer color-interpolation-filters="sRGB">
					<fefuncr type="table" tablevalues="0 0.96470588235294" />
					<fefuncg type="table" tablevalues="0 0.96470588235294" />
					<fefuncb type="table" tablevalues="0 0.96470588235294" />
					<fefunca type="table" tablevalues="1 1" />
				</fecomponenttransfer>
				<fecomposite in2="SourceGraphic" operator="in" />
			</filter>
		</defs>
	</svg>
</body>

</html>