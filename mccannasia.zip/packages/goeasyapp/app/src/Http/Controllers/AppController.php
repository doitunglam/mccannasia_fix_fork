<?php

namespace Goeasyapp\App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Goeasyapp\Core\Http\Hooks\LoginValidateHook;
use Goeasyapp\Core\Http\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;

class AppController extends Controller
{
    private $useHook;
    private $useRepository;
    public function __construct(LoginValidateHook $LoginValidateHook, UserRepository $UserRepository)
    {
        $this->useHook = $LoginValidateHook;
        $this->useRepository = $UserRepository;
    }
    public function home()
    {
        return view('app::home');
    }
    public function introduce($id)
    {
        session()->put('introduce', $id);
        return view('app::home');
    }
    public function dashboard()
    {
        return view('app::dashboard');
    }
    public function localeCn()
    {
        session()->put('locale', 'cn');
        return redirect()->back();
    }
    public function localeEn()
    {
        session()->put('locale', 'en');
        return redirect()->back();
    }
    public function localeVi()
    {
        session()->put('locale', 'vi');
        return redirect()->back();
    }
}