<?php

namespace Goeasyapp\Core\Http\Repositories;

use App\Models\User;

class UserRepository
{

}