<?php

namespace Goeasyapp\Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use PDO;

class Language extends Model
{
    use HasFactory;
    protected $fillable = [];
    protected $guarded = [];
    public static function test()
    {

    }
}