<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewItem extends Model
{
    protected $fillable = [

    ];
}