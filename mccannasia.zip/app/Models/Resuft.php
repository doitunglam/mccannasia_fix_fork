<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Resuft extends Model
{
    protected $fillable = [

    ];
}