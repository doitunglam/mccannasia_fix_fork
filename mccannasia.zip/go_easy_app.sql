-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2023 at 03:28 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `go_easy_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `link_` varchar(225) DEFAULT NULL,
  `image` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `link_`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'https://translate.google.com/?sl=vi&tl=en&text=gi%E1%BB%9Bi%20thi%E1%BB%87u&op=translate', '/upload/images/files/banner1.png', 1, '2023-03-01 04:02:44', '2023-03-01 04:03:54'),
(2, 'https://pub2.accesstrade.vn/campaign', '/upload/images/files/banner2.png', 1, '2023-03-01 04:03:11', '2023-03-01 04:03:51');

-- --------------------------------------------------------

--
-- Table structure for table `campains`
--

CREATE TABLE `campains` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `reson_cancel` text DEFAULT NULL,
  `short_content` text DEFAULT NULL,
  `link_` varchar(225) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `list_task` text DEFAULT NULL,
  `date_public` varchar(225) DEFAULT NULL,
  `date_end` int(11) DEFAULT NULL,
  `price_day` int(11) DEFAULT NULL,
  `registration_fee` int(11) DEFAULT NULL,
  `code` varchar(225) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `users` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `campains`
--

INSERT INTO `campains` (`id`, `name`, `description`, `reson_cancel`, `short_content`, `link_`, `image`, `list_task`, `date_public`, `date_end`, `price_day`, `registration_fee`, `code`, `price`, `status`, `users`, `created_at`, `updated_at`, `category`) VALUES
(3, 'VNPAY', 'VNPAY - Ví điện tử đầu tiên dành cho gia đình Việt, đáp ứng đa dạng nhu cầu thanh toán các dịch vụ hàng ngày của bạn và gia đình một cách nhanh chóng, tiện lợi, an toàn.\nQuản lý tiện lợi với Ví gia đình, mở ví thành viên cho người thân, đặt hạn mức và theo dõi chi tiêu dễ dàng. Mua sắm cùng VNPAYQR, quét mã VNPAYQR thanh toán siêu nhanh, nhận ưu đãi độc quyền tại hơn 150.000 điểm thanh toán cùng nhiều tính năng khác như chuyển tiền, Nạp tiền điện thoại, Thanh toán hóa đơn, Đặt vé máy bay, Đặt vé tàu, Gọi taxi…', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'VNPAY - Ví điện tử đầu tiên dành cho gia đình Việt, đáp ứng đa dạng nhu cầu thanh toán các dịch vụ hàng ngày của bạn và gia đình một cách nhanh chóng, tiện lợi, an toàn.\nQuản lý tiện lợi với Ví gia đình, mở ví thành viên cho người thân, đặt hạn mức và theo dõi chi tiêu dễ dàng. Mua sắm cùng VNPAYQR, quét mã VNPAYQR thanh toán siêu nhanh, nhận ưu đãi độc quyền tại hơn 150.000 điểm thanh toán cùng nhiều tính năng khác như chuyển tiền, Nạp tiền điện thoại, Thanh toán hóa đơn, Đặt vé máy bay, Đặt vé tàu, Gọi taxi…', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u v\\u00ea\\u0300 app VNPAY tr\\u00ean trang facebook ca\\u0301 nh\\u00e2n, va\\u0300 zalo ca\\u0301 nh\\u00e2n 1 nga\\u0300y 2 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 6000000, NULL, 200000, 1, NULL, '2023-02-27 01:34:45', '2023-03-01 03:11:03', 1),
(4, 'Bank Số Đẹp', 'Bank Số Đẹp là dịch vụ mở tài khoản của các ngân hàng/ví điện tử chỉ trong vòng 1 click. Dịch vụ Bank Số Đẹp với ưu điểm nhanh gọn, tiện lợi, online 100% không cần phải ra ngân hàng.\n\nBank Số Đẹp là một website tổng hợp nhiều ngân hàng/ví điện tử khác nhau giúp cho khách hàng không phải mất thời gian tìm hiểu và lựa chọn.\n\nKhách hàng lựa chọn mở tài khoản trên website Bank Số Đẹp, sẽ nhận ngay voucher mua sắm trên các sàn thương mại điện tử.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Bank Số Đẹp là dịch vụ mở tài khoản của các ngân hàng/ví điện tử chỉ trong vòng 1 click. Dịch vụ Bank Số Đẹp với ưu điểm nhanh gọn, tiện lợi, online 100% không cần phải ra ngân hàng.\n\nBank Số Đẹp là một website tổng hợp nhiều ngân hàng/ví điện tử khác nhau giúp cho khách hàng không phải mất thời gian tìm hiểu và lựa chọn.\n\nKhách hàng lựa chọn mở tài khoản trên website Bank Số Đẹp, sẽ nhận ngay voucher mua sắm trên các sàn thương mại điện tử.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u v\\u00ea\\u0300 app tr\\u00ean trang facebook ca\\u0301 nh\\u00e2n, va\\u0300 zalo ca\\u0301 nh\\u00e2n 1 nga\\u0300y 2 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 4000000, NULL, 150000, 1, '[3,4]', '2023-02-27 01:34:45', '2023-03-01 03:11:02', 1),
(5, 'BTASKEE - Ứng dụng giúp việc nhà số 1', 'Công ty TNHH BTaskee được thành lập vào ngày 30 tháng 03 năm 2016 bởi CEO – Founder Nathan Do (Đỗ Đắc Nhân Tâm).\nBTaskee là doanh nghiệp tiên phong trong việc ứng dụng công nghệ vào ngành giúp việc nhà ở Việt Nam. Chúng tôi cung cấp đa dịch vụ tiện ích như: dọn dẹp nhà, vệ sinh máy lạnh, đi chợ, … tại Đông Nam Á. Thông qua ứng dụng đặt lịch dành cho khách hàng bTaskee và ứng dụng nhận việc của cộng tác viên bTaskee Partner, khách hàng và cộng tác viên có thể chủ động đăng và nhận việc trực tiếp trên ứng dụng.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Công ty TNHH BTaskee được thành lập vào ngày 30 tháng 03 năm 2016 bởi CEO – Founder Nathan Do (Đỗ Đắc Nhân Tâm).\nBTaskee là doanh nghiệp tiên phong trong việc ứng dụng công nghệ vào ngành giúp việc nhà ở Việt Nam. Chúng tôi cung cấp đa dịch vụ tiện ích như: dọn dẹp nhà, vệ sinh máy lạnh, đi chợ, … tại Đông Nam Á. Thông qua ứng dụng đặt lịch dành cho khách hàng bTaskee và ứng dụng nhận việc của cộng tác viên bTaskee Partner, khách hàng và cộng tác viên có thể chủ động đăng và nhận việc trực tiếp trên ứng dụng.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u v\\u00ea\\u0300 app tr\\u00ean trang facebook ca\\u0301 nh\\u00e2n, va\\u0300 zalo ca\\u0301 nh\\u00e2n 1 nga\\u0300y 2 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 6000000, NULL, 200000, 1, NULL, '2023-02-27 01:34:45', '2023-03-01 03:11:04', 1),
(6, 'MB Bank - MỞ TÀI KHOẢN', 'Ngân hàng Quân đội - viết tắt là MB, là một ngân hàng thương mại cổ phần của Việt Nam, một doanh nghiệp trực thuộc Bộ Quốc phòng. Ngày 14/02/2020 MB ra mắt phiên bản App mới đi kèm vô vàn khuyến mãi dành cho khách hàng MB cũng như các khách hàng mới. ACCESSTRADE sẽ đồng hành cùng MB Bank trong chiến dịch ra mắt phiên bản App mới.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Ngân hàng Quân đội - viết tắt là MB, là một ngân hàng thương mại cổ phần của Việt Nam, một doanh nghiệp trực thuộc Bộ Quốc phòng. Ngày 14/02/2020 MB ra mắt phiên bản App mới đi kèm vô vàn khuyến mãi dành cho khách hàng MB cũng như các khách hàng mới. ACCESSTRADE sẽ đồng hành cùng MB Bank trong chiến dịch ra mắt phiên bản App mới.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u v\\u00ea\\u0300 app tr\\u00ean trang facebook ca\\u0301 nh\\u00e2n, va\\u0300 zalo ca\\u0301 nh\\u00e2n 1 nga\\u0300y 2 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 6000000, NULL, 200000, 1, NULL, '2023-02-27 01:34:45', '2023-03-01 03:11:05', 1),
(7, 'VP Bank - Mở Tài Khoản Ngân Hàng (Web)', 'Ngân hàng TMCP Việt Nam Thịnh Vượng (viết tắt VPBank) là một ngân hàng ở Việt Nam được thành lập ngày 12 tháng 08 năm 1993. Sau 21 năm hoạt động, VPBank đã nâng vốn điều lệ lên 6.347 tỷ đồng, phát triển mạng lưới lên hơn 200 điểm giao dịch, với đội ngũ trên 7.000 cán bộ nhân viên. Là thành viên của nhóm các ngân hàng lớn hàng đầu Việt Nam (G12). \nVPBANk eKYC là giải pháp định danh khách hàng trực tuyến, cho phép ngân hàng vượt qua mọi rào cản địa lý và thời gian để định danh khách hàng 100% online dựa vào các thông tin sinh trắc học (biometrics) mà không cần gặp mặt trực tiếp như quy trình hiện tại.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Ngân hàng TMCP Việt Nam Thịnh Vượng (viết tắt VPBank) là một ngân hàng ở Việt Nam được thành lập ngày 12 tháng 08 năm 1993. Sau 21 năm hoạt động, VPBank đã nâng vốn điều lệ lên 6.347 tỷ đồng, phát triển mạng lưới lên hơn 200 điểm giao dịch, với đội ngũ trên 7.000 cán bộ nhân viên. Là thành viên của nhóm các ngân hàng lớn hàng đầu Việt Nam (G12). \nVPBANk eKYC là giải pháp định danh khách hàng trực tuyến, cho phép ngân hàng vượt qua mọi rào cản địa lý và thời gian để định danh khách hàng 100% online dựa vào các thông tin sinh trắc học (biometrics) mà không cần gặp mặt trực tiếp như quy trình hiện tại.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u v\\u00ea\\u0300 app tr\\u00ean trang facebook ca\\u0301 nh\\u00e2n, va\\u0300 zalo ca\\u0301 nh\\u00e2n 1 nga\\u0300y 2 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 6000000, NULL, 200000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 1),
(8, 'Doctor Đồng', 'Doctor Đồng là dịch vụ tư vấn tài chính cho các khoản vay cầm cố ngắn hạn với khoản vay từ 1 đến 10 triệu đồng, các lựa chọn kỳ hạn vay là 10, 20 hoặc 30 ngày được cung cấp bởi các đối tác cho vay của chúng tôi. Hiện nay, đối tác cho vay chiến lược các khoản vay cầm cố của Doctor Đồng là Công ty TNHH MTV TMDV Vạn An Phát (VAP).Thanh toán khoản vay sẽ được thực hiện vào cuối kỳ hạn như quy định trong Hợp đồng Vay cầm cố.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Doctor Đồng là dịch vụ tư vấn tài chính cho các khoản vay cầm cố ngắn hạn với khoản vay từ 1 đến 10 triệu đồng, các lựa chọn kỳ hạn vay là 10, 20 hoặc 30 ngày được cung cấp bởi các đối tác cho vay của chúng tôi. Hiện nay, đối tác cho vay chiến lược các khoản vay cầm cố của Doctor Đồng là Công ty TNHH MTV TMDV Vạn An Phát (VAP).Thanh toán khoản vay sẽ được thực hiện vào cuối kỳ hạn như quy định trong Hợp đồng Vay cầm cố.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(9, 'Robocash - Hoa hồng cao nhất thị trường', 'Robocash cung cấp dịch vụ cho vay nhanh online hoàn toàn tự động, giải ngân trong ngày. Bất kỳ ngày nào trong tuần, bất kể thời gian nào, ngày lễ hoặc ngày nghỉ cũng được cho duyệt vay. \"Robocash\" là hệ thống hiện đại tân tiến, có thể tự động xử lý 1800 dữ liệu khách hàng cùng một lúc dựa vào thông tin được cung cấp theo mẫu.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Robocash cung cấp dịch vụ cho vay nhanh online hoàn toàn tự động, giải ngân trong ngày. Bất kỳ ngày nào trong tuần, bất kể thời gian nào, ngày lễ hoặc ngày nghỉ cũng được cho duyệt vay. \"Robocash\" là hệ thống hiện đại tân tiến, có thể tự động xử lý 1800 dữ liệu khách hàng cùng một lúc dựa vào thông tin được cung cấp theo mẫu.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(10, 'Senmo - Vay Tiền Nhanh', 'Senmo là một công ty tư vấn tài chính lớn chuyên cho vay trực tuyến. Với quy trình cho vay hoàn toàn trực tuyến, quy trình vay đơn giản dễ hiểu, điều kiện thuận lợi.\n\nLợi ích chương trình đối tác:\n\nĐiều kiện cho vay thuận lợi;\nLãi suất thấp;\nTối thiểu nhất điều kiện bắt buộc để vay vốn.\nLợi thế và tính năng cạnh tranh:\n\nQuy trình đơn giản để gia hạn khoản vay;\nKhả năng kéo dài thời gian hoàn trả nợ; \nThời gian xác nhận khoảng vay ngắn trong vòng 6 phút;\nSố tiền vay lên đến 20 Triệu VND;\nLãi suất hấp dẫn 1,85%.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Senmo là một công ty tư vấn tài chính lớn chuyên cho vay trực tuyến. Với quy trình cho vay hoàn toàn trực tuyến, quy trình vay đơn giản dễ hiểu, điều kiện thuận lợi.\n\nLợi ích chương trình đối tác:\n\nĐiều kiện cho vay thuận lợi;\nLãi suất thấp;\nTối thiểu nhất điều kiện bắt buộc để vay vốn.\nLợi thế và tính năng cạnh tranh:\n\nQuy trình đơn giản để gia hạn khoản vay;\nKhả năng kéo dài thời gian hoàn trả nợ; \nThời gian xác nhận khoảng vay ngắn trong vòng 6 phút;\nSố tiền vay lên đến 20 Triệu VND;\nLãi suất hấp dẫn 1,85%.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(11, 'Tamo', 'Tamo là nền tảng tư vấn và cung cấp các giải pháp tài chính trực tuyến 24/7, nhằm hỗ trợ cho các nhu cầu tài chính đột xuất của bạn. Thấu hiểu được những vấn đề tài chính bạn đang gặp phải, chúng tôi cố gắng mang đến bạn những giải pháp tài chính đơn giản, nhanh chóng và thuận tiện nhất.\n\nƯu điểm khi khách hàng vay qua Tamo:\n- Nhận xét duyệt hồ sơ chỉ trong 3 phút\n- Không yêu cầu chứng từ bảo lãnh hoặc chứng minh thu nhập\n- Đăng ký vay 24/7 nhanh chóng, thuận tiện và dễ dàng\n- Tỷ lệ duyệt đơn cao', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Tamo là nền tảng tư vấn và cung cấp các giải pháp tài chính trực tuyến 24/7, nhằm hỗ trợ cho các nhu cầu tài chính đột xuất của bạn. Thấu hiểu được những vấn đề tài chính bạn đang gặp phải, chúng tôi cố gắng mang đến bạn những giải pháp tài chính đơn giản, nhanh chóng và thuận tiện nhất.\n\nƯu điểm khi khách hàng vay qua Tamo:\n- Nhận xét duyệt hồ sơ chỉ trong 3 phút\n- Không yêu cầu chứng từ bảo lãnh hoặc chứng minh thu nhập\n- Đăng ký vay 24/7 nhanh chóng, thuận tiện và dễ dàng\n- Tỷ lệ duyệt đơn cao', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(12, 'MONEYCAT - VAY TIỀN 0% LÃI', 'MoneyCat là một trong những công ty tư vấn tài chính lớn uy tín nhất hiện nay. \nDịch vụ MoneyCat cung cấp giải pháp tài chính cho khách hàng chỉ trong vòng 5 phút điền thông tin và cam kết giải ngân trong ngày.\n\nƯu đãi đặc biệt dành cho khách hàng mới: 0% lãi suất cho 7 ngày đầu tiên kể từ khi giải ngân.\n\nĐối với trường hợp về giải ngân từ hệ thống, vui lòng liên hệ tới số hotline hoặc truy cập website: https://moneycat.vn/connect/#form\n\nLưu ý: LÝ DO CHIẾN DỊCH MONEYCAT CPS KHÔNG LÊN HOA HỒNG\nCụ thể, tất cả các khách hàng mới đăng ký tại MoneyCat đều được giải ngân 250k cho lần vay đầu tiên. Vì vậy, những đơn này đều được ghi nhận trên hệ thống của khách hàng và Accesstrade.\n\nĐiều kiện khách hàng:\n- Những Khách hàng có việc làm\n- Độ tuổi từ 22 tới 60 tuổi', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'MoneyCat là một trong những công ty tư vấn tài chính lớn uy tín nhất hiện nay. \nDịch vụ MoneyCat cung cấp giải pháp tài chính cho khách hàng chỉ trong vòng 5 phút điền thông tin và cam kết giải ngân trong ngày.\n\nƯu đãi đặc biệt dành cho khách hàng mới: 0% lãi suất cho 7 ngày đầu tiên kể từ khi giải ngân.\n\nĐối với trường hợp về giải ngân từ hệ thống, vui lòng liên hệ tới số hotline hoặc truy cập website: https://moneycat.vn/connect/#form\n\nLưu ý: LÝ DO CHIẾN DỊCH MONEYCAT CPS KHÔNG LÊN HOA HỒNG\nCụ thể, tất cả các khách hàng mới đăng ký tại MoneyCat đều được giải ngân 250k cho lần vay đầu tiên. Vì vậy, những đơn này đều được ghi nhận trên hệ thống của khách hàng và Accesstrade.\n\nĐiều kiện khách hàng:\n- Những Khách hàng có việc làm\n- Độ tuổi từ 22 tới 60 tuổi', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(13, 'ONCREDIT CPS - 0% lãi Gói vay đầu', 'OnCredit tự hào là công ty hàng đầu Việt Nam trong lĩnh vực cho vay tiền online, đem đến giải pháp tài chính Tối Ưu, An Toàn và Minh Bạch cho mọi khách hàng. \n\nOnCredit cho vay tiền online mọi lúc mọi nơi 24/7 kể cả thứ 7, chủ nhật và ngày lễ, giúp mọi người tiết kiệm thời gian, dễ dàng tiếp cận dịch vụ tài chính văn minh, hiện đại; nhận tiền về tài khoản nhanh chóng. Lãi suất vay theo ngày, không theo chu kỳ; khách hàng có thể tự do lựa chọn khoản vay với chính sách ưu đãi hấp dẫn.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'OnCredit tự hào là công ty hàng đầu Việt Nam trong lĩnh vực cho vay tiền online, đem đến giải pháp tài chính Tối Ưu, An Toàn và Minh Bạch cho mọi khách hàng. \n\nOnCredit cho vay tiền online mọi lúc mọi nơi 24/7 kể cả thứ 7, chủ nhật và ngày lễ, giúp mọi người tiết kiệm thời gian, dễ dàng tiếp cận dịch vụ tài chính văn minh, hiện đại; nhận tiền về tài khoản nhanh chóng. Lãi suất vay theo ngày, không theo chu kỳ; khách hàng có thể tự do lựa chọn khoản vay với chính sách ưu đãi hấp dẫn.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(14, 'TINVAY - Vay dễ dàng, Duyệt cấp tốc', 'CICDATA là công ty hàng đầu trong lĩnh vực khai thác dữ liệu và là công ty duy nhất hợp tác với tât cả nhà mạng tại Việt Nam. Dựa trên nền tảng Dữ liệu lớn (Big data) và Máy học (Machine Learning), CIC DATA cung cấp các dịch vụ tiêu chuẩn cao trong việc chấm điểm tín dụng và tạo khách hàng vay tín chấp và thẻ tín dụng tiềm năng. TINVAY là 1 giải pháp được phát triển bởi CICDATA\nTINVAY là nền tảng kết nối và sơ duyệt khoản vay từ các ngân hàng và tổ chức tài chính lớn nhất Việt Nam. TINVAY ứng dụng công nghệ trí tuệ nhân tạo AI và dữ liệu lớn Big Data để tìm kiếm và phê duyệt tự động khoản vay phù hợp nhất cho khách hàng, mà không cần chứng minh tài chính hay thế chấp tài sản.\n\nTINVAY sẽ nhận các đăng ký vay tín dụng của KH sau đó phân tích mức độ tín nhiệm và tìm kiếm khoản vay có tỉ lệ phê duyệt cao trong mạng lưới các tổ chức tài chính, ngân hàng đối tác. Với các thủ tục đăng ký vay tối thiểu, khách hàng sẽ được được hỗ trợ tài chính bởi các tổ chức hàng đầu với thời gian giải ngân không quá 48 tiếng.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'CICDATA là công ty hàng đầu trong lĩnh vực khai thác dữ liệu và là công ty duy nhất hợp tác với tât cả nhà mạng tại Việt Nam. Dựa trên nền tảng Dữ liệu lớn (Big data) và Máy học (Machine Learning), CIC DATA cung cấp các dịch vụ tiêu chuẩn cao trong việc chấm điểm tín dụng và tạo khách hàng vay tín chấp và thẻ tín dụng tiềm năng. TINVAY là 1 giải pháp được phát triển bởi CICDATA\nTINVAY là nền tảng kết nối và sơ duyệt khoản vay từ các ngân hàng và tổ chức tài chính lớn nhất Việt Nam. TINVAY ứng dụng công nghệ trí tuệ nhân tạo AI và dữ liệu lớn Big Data để tìm kiếm và phê duyệt tự động khoản vay phù hợp nhất cho khách hàng, mà không cần chứng minh tài chính hay thế chấp tài sản.\n\nTINVAY sẽ nhận các đăng ký vay tín dụng của KH sau đó phân tích mức độ tín nhiệm và tìm kiếm khoản vay có tỉ lệ phê duyệt cao trong mạng lưới các tổ chức tài chính, ngân hàng đối tác. Với các thủ tục đăng ký vay tối thiểu, khách hàng sẽ được được hỗ trợ tài chính bởi các tổ chức hàng đầu với thời gian giải ngân không quá 48 tiếng.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(15, 'Tiền Ơi', 'Cuối tháng tiền lương chưa có, bao nhiêu khoản phải lo? Bạn đã quá chán các thủ tục rườm rà đến từ ngân hàng. Tiền Ơi sẽ giúp bạn giải quyết các vấn đề về tài chính một cách đơn giản và dễ dàng nhất. Thủ tục hoàn toàn online, không mất phí tư vấn. Giải ngân ngay trong ngày.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Cuối tháng tiền lương chưa có, bao nhiêu khoản phải lo? Bạn đã quá chán các thủ tục rườm rà đến từ ngân hàng. Tiền Ơi sẽ giúp bạn giải quyết các vấn đề về tài chính một cách đơn giản và dễ dàng nhất. Thủ tục hoàn toàn online, không mất phí tư vấn. Giải ngân ngay trong ngày.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(16, 'FINDO', 'Findo.vn là nền tảng tư vấn và cung cấp các giải pháp tài chính trực tuyến 24/7. Dịch vụ Findo.vn phục vụ đối tượng khách hàng là người Việt Nam trong độ tuổi từ 20 – 60 tuổi, có việc làm thu nhập ổn định. Vay tiền online với findo Rất đơn giản, bạn chỉ cần chuẩn bị Chứng minh nhân dân/ Thẻ Căn cước công dân và hình chân dung để gửi yêu cầu đăng ký hồ sơ.\nFindo.vn là nền tảng tư vấn và cung cấp các giải pháp tài chính trực tuyến 24/7, nhằm hỗ trợ cho các nhu cầu tài chính đột xuất của bạn.\nThấu hiểu được những vấn đề tài chính bạn đang gặp phải, chúng tôi cố gắng mang đến bạn những giải pháp tài chính đơn giản, nhanh chóng và thuận tiện nhất.\nCông ty TNHH SOFI SOLUTIONS là đơn vị quản lý và thực hiện hoạt động tư vấn, kết nối tài chính.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Findo.vn là nền tảng tư vấn và cung cấp các giải pháp tài chính trực tuyến 24/7. Dịch vụ Findo.vn phục vụ đối tượng khách hàng là người Việt Nam trong độ tuổi từ 20 – 60 tuổi, có việc làm thu nhập ổn định. Vay tiền online với findo Rất đơn giản, bạn chỉ cần chuẩn bị Chứng minh nhân dân/ Thẻ Căn cước công dân và hình chân dung để gửi yêu cầu đăng ký hồ sơ.\nFindo.vn là nền tảng tư vấn và cung cấp các giải pháp tài chính trực tuyến 24/7, nhằm hỗ trợ cho các nhu cầu tài chính đột xuất của bạn.\nThấu hiểu được những vấn đề tài chính bạn đang gặp phải, chúng tôi cố gắng mang đến bạn những giải pháp tài chính đơn giản, nhanh chóng và thuận tiện nhất.\nCông ty TNHH SOFI SOLUTIONS là đơn vị quản lý và thực hiện hoạt động tư vấn, kết nối tài chính.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(17, 'Avay.vn', 'AVAY là giải pháp tài chính giúp kết nối người cần vay tới các tổ chức tài chính lớn và uy tín trên thị trường Việt Nam. Sử dụng công nghệ Big Data từ Trusting Social, một tổ chức quy tụ các giáo sư, tiến sĩ về khoa học dữ liệu và khoa học máy tính, tới từ các tổ chức hàng đầu thế giới như: SRI, IBM Research, Microsoft, Goldman Sachs, Vodafone, Barclays.\n\nAVAY áp dụng công nghệ tự động hóa trong việc đánh giá khả năng chi trả của người vay, gửi thông tin cho ngân hàng phù hợp và duyệt tự động các khoản vay.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'AVAY là giải pháp tài chính giúp kết nối người cần vay tới các tổ chức tài chính lớn và uy tín trên thị trường Việt Nam. Sử dụng công nghệ Big Data từ Trusting Social, một tổ chức quy tụ các giáo sư, tiến sĩ về khoa học dữ liệu và khoa học máy tính, tới từ các tổ chức hàng đầu thế giới như: SRI, IBM Research, Microsoft, Goldman Sachs, Vodafone, Barclays.\n\nAVAY áp dụng công nghệ tự động hóa trong việc đánh giá khả năng chi trả của người vay, gửi thông tin cho ngân hàng phù hợp và duyệt tự động các khoản vay.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(18, 'ATM Online CPS', 'ATM Online là giải pháp tài chính trực tuyến ưu việt hàng đầu tại Việt Nam, với các ưu điểm như: nhanh chóng, tiện lợi, thanh toán linh hoạt và chi phí cực kỳ hợp lý. \n\nƯu điểm của ATM Online là khách hàng có thể ngay lập tức biết được mình được duyệt vay vốn hay không', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'ATM Online là giải pháp tài chính trực tuyến ưu việt hàng đầu tại Việt Nam, với các ưu điểm như: nhanh chóng, tiện lợi, thanh toán linh hoạt và chi phí cực kỳ hợp lý. \n\nƯu điểm của ATM Online là khách hàng có thể ngay lập tức biết được mình được duyệt vay vốn hay không', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(19, 'VAY VND CPS', 'VayVNĐ là nhà cung cấp dịch vụ tư vấn giải pháp tài chính và cung cấp giải pháp tiền mặt trực tuyến. Mỗi ngày, với sự giúp đỡ của chúng tôi, rất nhiều người trên cả nước đã giải quyết được các vấn đề tài chính khẩn cấp của mình với thủ tục đang ký đơn giản.\n\nNhiệm vụ của chúng tôi là trở thành một đối tác đáng tin cậy bằng cách cung cấp các giải pháp tài chính với điều khoản thuận lợi nhất cho những người vướng vào Hoàn Cảnh khó khăn về tài chính, làm cho thị trường cho vay ở Việt Nam trở nên vô cùng minh bạch, đơn giản với điều kiện phù hợp nhất đối với từng đối tượng khách hàng.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'VayVNĐ là nhà cung cấp dịch vụ tư vấn giải pháp tài chính và cung cấp giải pháp tiền mặt trực tuyến. Mỗi ngày, với sự giúp đỡ của chúng tôi, rất nhiều người trên cả nước đã giải quyết được các vấn đề tài chính khẩn cấp của mình với thủ tục đang ký đơn giản.\n\nNhiệm vụ của chúng tôi là trở thành một đối tác đáng tin cậy bằng cách cung cấp các giải pháp tài chính với điều khoản thuận lợi nhất cho những người vướng vào Hoàn Cảnh khó khăn về tài chính, làm cho thị trường cho vay ở Việt Nam trở nên vô cùng minh bạch, đơn giản với điều kiện phù hợp nhất đối với từng đối tượng khách hàng.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(20, 'Vay Quá Dễ', 'Vay Quá Dễ là dịch vụ miễn phí lựa chọn tức thời các khoản vay 0%. Dịch vụ Vay Quá Dễ nghiên cứu các đề xuất từ những công ty đáp ứng 4 tiêu chí: không có các khoản thanh toán ẩn, uy tín được kiểm chứng, cấp tín dụng trực tuyến và bảo vệ dữ liệu cá nhân.', 'Không thực hiện nhiệm vụ 3 ngày liên tiếp, và dươi 25 ngày trong 1 tháng\nDùng tài khoản facebook, zalo không chính chủ( acc clone, tạo mơi)\nKhông báo cáo hoàn thành nhiệm vụ hàng ngày.', 'Vay Quá Dễ là dịch vụ miễn phí lựa chọn tức thời các khoản vay 0%. Dịch vụ Vay Quá Dễ nghiên cứu các đề xuất từ những công ty đáp ứng 4 tiêu chí: không có các khoản thanh toán ẩn, uy tín được kiểm chứng, cấp tín dụng trực tuyến và bảo vệ dữ liệu cá nhân.', NULL, NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u app tr\\u00ean trang ca\\u0301 nh\\u00e2n facebook, zalo m\\u00f4\\u0303i nga\\u0300y 3 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 ng\\u01b0\\u01a1i ta\\u0309i app va\\u0300 \\u0111\\u0103ng ky\\u0301 ta\\u0300i khoa\\u0309n tha\\u0300nh c\\u00f4ng.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n co\\u0301 m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 3 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', NULL, NULL, NULL, 20000000, NULL, 400000, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:35:53', 2),
(21, 'Unica - Học từ chuyên gia', 'Unica là một hệ thống đào tạo trực tuyến, cổng kết nối Chuyên gia với Học viên, được vận hành bởi iNET Academy - Học viện Internet Marketing với hơn 100.000 học viên.\n\nĐây là campaign giáo dục rất đa dạng về các khóa học, chủ đề, là thương hiệu lớn được nhiều học viên tin tưởng lựa chọn. Đặc biệt Unica là một trong những chiến dịch có mức hoa hồng cực hấp dẫn cùng mức tăng trưởng mạnh qua các tháng.', NULL, 'Unica là một hệ thống đào tạo trực tuyến, cổng kết nối Chuyên gia với Học viên, được vận hành bởi iNET Academy - Học viện Internet Marketing với hơn 100.000 học viên.\n\nĐây là campaign giáo dục rất đa dạng về các khóa học, chủ đề, là thương hiệu lớn được nhiều học viên tin tưởng lựa chọn. Đặc biệt Unica là một trong những chiến dịch có mức hoa hồng cực hấp dẫn cùng mức tăng trưởng mạnh qua các tháng.', NULL, NULL, '[null]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 3),
(22, 'ELSA', 'ELSA là ứng dụng tốt nhất trên thế giới giúp bạn học nói tiếng Anh thành thạo như người bản xứ một cách hiệu quả hơn, dễ dàng hơn, tiết kiệm hơn.\n\nCông nghệ Trí Tuệ Nhân Tạo (AI) của ELSA là độc quyền được phát triển riêng cho mục đích hướng dẫn người dùng phát âm tiếng Anh.\n\nELSA là gia sư bản địa trực tuyến của riêng bạn, luôn sẵn sàng giúp bạn luyện tập 24/7 với phản hồi tức thì và hướng dẫn chính xác tuyệt vời.', NULL, 'ELSA là ứng dụng tốt nhất trên thế giới giúp bạn học nói tiếng Anh thành thạo như người bản xứ một cách hiệu quả hơn, dễ dàng hơn, tiết kiệm hơn.\n\nCông nghệ Trí Tuệ Nhân Tạo (AI) của ELSA là độc quyền được phát triển riêng cho mục đích hướng dẫn người dùng phát âm tiếng Anh.\n\nELSA là gia sư bản địa trực tuyến của riêng bạn, luôn sẵn sàng giúp bạn luyện tập 24/7 với phản hồi tức thì và hướng dẫn chính xác tuyệt vời.', NULL, NULL, '[null]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 3),
(23, 'ILA Education - Tiếng anh cho bé 3 - 16 tuổi', 'ILA Vietnam là tổ chức đào tạo Anh ngữ hàng đầu Việt Nam với 25 năm kinh nghiệm. ILA tiên phong mang đến những phương pháp học tập tiên tiến, chuẩn quốc tế cùng các chương trình học phù hợp với mọi lứa tuổi và mục tiêu học tập.', NULL, 'ILA Vietnam là tổ chức đào tạo Anh ngữ hàng đầu Việt Nam với 25 năm kinh nghiệm. ILA tiên phong mang đến những phương pháp học tập tiên tiến, chuẩn quốc tế cùng các chương trình học phù hợp với mọi lứa tuổi và mục tiêu học tập.', NULL, NULL, '[null]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 3),
(24, 'Monkey Junior', 'Khoa học chứng minh 0-10 tuổi là giai đoạn vàng phát triển ngôn ngữ. Monkey Junior phát triển chương trình học ngôn ngữ TOÀN DIỆN NHẤT từ trước đến nay áp dụng phương pháp Giáo dục sớm, giúp trẻ phát triển vượt bậc năng lực ngôn ngữ trong giai đoạn này.\n\nVới 4 sản phẩm chính lần này, Early Start mong muốn đẩy mạnh hơn nữa việc cải thiện tiếng anh của trẻ qua các gói/ thẻ học online  \n\n- Monkey Junior: Chương trình học tiếng anh trẻ em \n\n- Monkey Math: Toán tiếng anh chuẩn Mỹ \n\n- Monkey Stories: chương trình truyện tiếng anh dành cho trẻ \n\n- V Monkey: Chương trình học tiếng Việt chuẩn của Bộ GD&ĐT', NULL, 'Khoa học chứng minh 0-10 tuổi là giai đoạn vàng phát triển ngôn ngữ. Monkey Junior phát triển chương trình học ngôn ngữ TOÀN DIỆN NHẤT từ trước đến nay áp dụng phương pháp Giáo dục sớm, giúp trẻ phát triển vượt bậc năng lực ngôn ngữ trong giai đoạn này.\n\nVới 4 sản phẩm chính lần này, Early Start mong muốn đẩy mạnh hơn nữa việc cải thiện tiếng anh của trẻ qua các gói/ thẻ học online  \n\n- Monkey Junior: Chương trình học tiếng anh trẻ em \n\n- Monkey Math: Toán tiếng anh chuẩn Mỹ \n\n- Monkey Stories: chương trình truyện tiếng anh dành cho trẻ \n\n- V Monkey: Chương trình học tiếng Việt chuẩn của Bộ GD&ĐT', NULL, NULL, '[null]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 3),
(25, 'UCAN - 1000 BÀI HỌC DOANH NHÂN', '1000 Bài học doanh nhân giúp bạn tham khảo và học hỏi hàng ngàn bài học từ các danh nhân nổi tiếng trong nhiều lĩnh vực như kinh doanh, quân sự, văn học, nghiên cứu khoa học, phát minh sáng chế… để nhanh chóng áp dụng cách tư duy của những người thành công và hoàn thiện bản thân trong suốt cuộc đời.', NULL, '1000 Bài học doanh nhân giúp bạn tham khảo và học hỏi hàng ngàn bài học từ các danh nhân nổi tiếng trong nhiều lĩnh vực như kinh doanh, quân sự, văn học, nghiên cứu khoa học, phát minh sáng chế… để nhanh chóng áp dụng cách tư duy của những người thành công và hoàn thiện bản thân trong suốt cuộc đời.', NULL, NULL, '[null]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 3),
(26, 'Tên kênh tiktok', NULL, 'Không thực hiện nhiệm vụ 3 ngày liên tiếp', NULL, NULL, NULL, '[\"Ha\\u0300ng nga\\u0300y va\\u0300o tha\\u0309 tim, comment n\\u00f4\\u0323i dung ti\\u0301ch c\\u01b0\\u0323c va\\u0300o 2 ba\\u0300i vi\\u00ea\\u0301t cu\\u0309a k\\u00eanh tiktok.\"]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 4),
(27, 'Chọn 1 shop bất kỳ', NULL, NULL, NULL, NULL, NULL, '[\"M\\u00f4\\u0303i nga\\u0300y \\u0111\\u0103ng 3-5 sa\\u0309n ph\\u00e2\\u0309m cu\\u0309a shop ke\\u0300m link mua ha\\u0300ng l\\u00ean trang facebook, zalo ca\\u0301 nh\\u00e2n.\"]', NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45', 5);

-- --------------------------------------------------------

--
-- Table structure for table `campain_items`
--

CREATE TABLE `campain_items` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `code` varchar(225) DEFAULT NULL,
  `url` varchar(225) DEFAULT NULL,
  `use_` varchar(225) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `campain_items`
--

INSERT INTO `campain_items` (`id`, `uid`, `cid`, `code`, `url`, `use_`, `created_at`, `updated_at`) VALUES
(1, 3, 4, '1677465908', 'eccbc87e4b5ce2fe28308fd9f2a7baf3', '', '2023-02-27 02:45:08', '2023-02-27 02:45:08'),
(3, 4, 4, '1677473185', 'a87ff679a2f3e71d9181a67b7542122c', 'eccbc87e4b5ce2fe28308fd9f2a7baf3', '2023-02-27 04:46:25', '2023-02-27 04:46:25');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(2252) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Mobile app', NULL, '2023-02-27 01:32:00', '2023-02-27 01:32:00'),
(2, 'Dịch vụ tài chính', NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45'),
(3, 'Giáo dục', NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45'),
(4, 'Tiktok', NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45'),
(5, 'Shopee', NULL, '2023-02-27 01:34:45', '2023-02-27 01:34:45');

-- --------------------------------------------------------

--
-- Table structure for table `category_news`
--

CREATE TABLE `category_news` (
  `id` int(11) NOT NULL,
  `name` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `image` varchar(225) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category_news`
--

INSERT INTO `category_news` (`id`, `name`, `description`, `status`, `image`, `created_at`, `updated_at`) VALUES
(2, '{\"en\":\"Englust\",\"vi\":\"vi\"}', '{\"en\":\"<p>asdasdasd<\\/p>\",\"vi\":\"<p>asdasdas<\\/p>\"}', NULL, '{\"en\":\"\\/upload\\/images\\/files\\/download%20(1).png\",\"vi\":\"\\/upload\\/images\\/files\\/Flag_of_Vietnam_svg.png\"}', '2023-02-15 11:56:40', '2023-02-15 11:56:40');

-- --------------------------------------------------------

--
-- Table structure for table `configs`
--

CREATE TABLE `configs` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `configs`
--

INSERT INTO `configs` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '[\"Techcombank\",\"Agribank\"]', '[\"19030444746014\",\"111111111111111111111111\"]', NULL, '2023-03-02 10:49:30');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `image` varchar(225) DEFAULT NULL,
  `value` longtext DEFAULT NULL,
  `page_value` longtext DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `test` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `code`, `image`, `value`, `page_value`, `status`, `created_at`, `updated_at`, `test`) VALUES
(2, 'English', 'en', '/upload/images/files/download%20(1).png', '{\"All.language\":\"Language\",\"All.save\":\"Save\",\"All.name\":\"Name\",\"All.image\":\"Image\",\"All.code\":\"Code\",\"All.category_new\":\"Category New\",\"All.blog\":\"Blog\",\"All.campain\":\"Campain\",\"All.agency\":\"Agency\",\"All.payment\":\"Payment\",\"All.list\":\"List\",\"All.create\":\"Create\",\"All.statistical\":\"Statistical\",\"All.campain_day\":\"Campain Day\",\"All.my_campain\":\"My Campain\",\"Language.test\":\"Test\"}', '{\"All\":{\"All.language\":\"Language\",\"All.save\":\"Save\",\"All.name\":\"Name\",\"All.image\":\"Image\",\"All.code\":\"Code\",\"All.category_new\":\"Category New\",\"All.blog\":\"Blog\",\"All.campain\":\"Campain\",\"All.agency\":\"Agency\",\"All.payment\":\"Payment\",\"All.list\":\"List\",\"All.create\":\"Create\",\"All.statistical\":\"Statistical\",\"All.campain_day\":\"Campain Day\",\"All.my_campain\":\"My Campain\"},\"Language\":{\"Language.test\":\"Test\"}}', NULL, '2023-02-14 22:10:59', '2023-02-27 13:17:44', NULL),
(3, 'Viet Nam', 'vi', '/upload/images/files/Flag_of_Vietnam_svg.png', '{\"All.language\":\"Ngon ngu\",\"All.save\":\"Luu\",\"All.name\":\"Ten\",\"All.image\":\"Anh\",\"All.code\":\"Ma\",\"All.category_new\":\"Danh Muc\",\"All.blog\":\"Bai Viet\",\"All.campain\":\"Chien Dich\",\"All.agency\":\"Doi tac\",\"All.payment\":\"Thanh toan\",\"All.list\":\"Danh sach\",\"All.create\":\"Tao moi\",\"All.statistical\":\"Bao cao\",\"All.campain_day\":\"Chien dich hom nay\",\"All.my_campain\":\"Chien dich cua toi\",\"Language.test\":null}', '{\"All\":{\"All.language\":\"Ngon ngu\",\"All.save\":\"Luu\",\"All.name\":\"Ten\",\"All.image\":\"Anh\",\"All.code\":\"Ma\",\"All.category_new\":\"Danh Muc\",\"All.blog\":\"Bai Viet\",\"All.campain\":\"Chien Dich\",\"All.agency\":\"Doi tac\",\"All.payment\":\"Thanh toan\",\"All.list\":\"Danh sach\",\"All.create\":\"Tao moi\",\"All.statistical\":\"Bao cao\",\"All.campain_day\":\"Chien dich hom nay\",\"All.my_campain\":\"Chien dich cua toi\"},\"Language\":{\"Language.test\":null}}', NULL, '2023-02-14 22:45:56', '2023-02-27 13:18:03', NULL),
(4, 'China', 'cn', NULL, '{\"All.language\":\"Tieng Trung\",\"All.save\":null,\"All.name\":null,\"All.image\":null,\"All.code\":null,\"All.category_new\":null,\"All.blog\":null,\"All.campain\":null,\"All.agency\":null,\"All.payment\":\"Thanh to\\u00e1n ti\\u1ebfng trung\",\"All.list\":null,\"All.create\":null,\"All.statistical\":null,\"All.campain_day\":null,\"All.my_campain\":null,\"Language.test\":null}', '{\"All\":{\"All.language\":\"Tieng Trung\",\"All.save\":null,\"All.name\":null,\"All.image\":null,\"All.code\":null,\"All.category_new\":null,\"All.blog\":null,\"All.campain\":null,\"All.agency\":null,\"All.payment\":\"Thanh to\\u00e1n ti\\u1ebfng trung\",\"All.list\":null,\"All.create\":null,\"All.statistical\":null,\"All.campain_day\":null,\"All.my_campain\":null},\"Language\":{\"Language.test\":null}}', NULL, '2023-03-01 01:44:19', '2023-03-01 01:46:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `language_pages`
--

CREATE TABLE `language_pages` (
  `id` int(11) NOT NULL,
  `name` int(225) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `new_items`
--

CREATE TABLE `new_items` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(225) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `new_items`
--

INSERT INTO `new_items` (`id`, `name`, `description`, `image`, `status`, `c_id`, `created_at`, `updated_at`) VALUES
(1, '{\"en\":\"asdsa\",\"vi\":\"asdasd\"}', '{\"en\":\"<p>dasdasd<\\/p>\",\"vi\":\"<p>asdasd<\\/p>\"}', '{\"en\":null,\"vi\":\"\\/upload\\/images\\/files\\/Flag_of_Vietnam_svg.png\"}', NULL, NULL, '2023-02-15 12:09:34', '2023-02-15 12:09:34');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `user_name` varchar(225) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `name` varchar(225) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user`, `user_name`, `amount`, `status`, `name`, `created_at`, `updated_at`, `type`) VALUES
(1, 1, 'Supper Admin', 2000, 1, 'English', '2023-02-15 22:38:23', '2023-02-15 23:01:04', NULL),
(2, 3, 'Đại lý 1', 50000, NULL, 'aaa', '2023-02-27 03:59:15', '2023-02-27 03:59:15', NULL),
(3, 1, 'Supper Admin', 6000000, NULL, NULL, '2023-03-01 05:18:37', '2023-03-01 05:18:37', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `resufts`
--

CREATE TABLE `resufts` (
  `id` int(11) NOT NULL,
  `campain` int(11) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `resuft` text DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `campain_name` text DEFAULT NULL,
  `user_name` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `list_task` text DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `use_` varchar(225) DEFAULT NULL,
  `date` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `resufts`
--

INSERT INTO `resufts` (`id`, `campain`, `user`, `resuft`, `status`, `campain_name`, `user_name`, `image`, `list_task`, `price`, `created_at`, `updated_at`, `use_`, `date`) VALUES
(2, 1, 1, '{\"1\":[\"\\/upload\\/images\\/files\\/1.PNG\",\"\\/upload\\/images\\/files\\/download%20(1).png\",\"\\/upload\\/images\\/files\\/Flag_of_Vietnam_svg.png\"],\"2\":[\"\\/upload\\/images\\/files\\/Flag_of_Vietnam_svg.png\"]}', 0, '{\"en\":\"What is Lorem Ipsum?\",\"vi\":\"What is Lorem Ipsum? viet nam\"}', 'Supper Admin', '{\"en\":\"\\/upload\\/images\\/files\\/download%20(1).png\",\"vi\":\"\\/upload\\/images\\/files\\/Flag_of_Vietnam_svg.png\"}', '{\"en\":[null,\"Chia s\\u1ebb  3 forum facebook english\",\"chia s\\u1ebb voz end\"],\"vi\":[null,\"Chia s\\u1ebb v\\u00e0o voz 1\",\"Chia s\\u1ebb v\\u00e0o voz2\"]}', 5000, '2023-02-15 23:24:07', '2023-02-15 23:34:13', NULL, NULL),
(3, 4, 3, '[[\"\\/upload\\/images\\/files\\/1.PNG\",\"\\/upload\\/images\\/files\\/download%20(1).png\"]]', 1, 'Bank Số Đẹp', 'Đại lý 1', NULL, '[\"\\u0110\\u0103ng ba\\u0300i gi\\u01a1i thi\\u00ea\\u0323u v\\u00ea\\u0300 app tr\\u00ean trang facebook ca\\u0301 nh\\u00e2n, va\\u0300 zalo ca\\u0301 nh\\u00e2n 1 nga\\u0300y 2 l\\u00e2\\u0300n.\\nM\\u00f4\\u0303i tu\\u00e2\\u0300n m\\u01a1i t\\u00f4\\u0301i thi\\u00ea\\u0309u 1 tha\\u0300nh vi\\u00ean \\u0111\\u0103ng ky\\u0301 tha\\u0300nh c\\u00f4ng ta\\u0300i khoa\\u0309n tr\\u00ean trang web McCannasia.com\"]', 150000, '2023-02-27 02:59:09', '2023-02-27 03:46:02', '', '27-02-2023');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'member',
  `amount` int(11) DEFAULT NULL,
  `image` varchar(225) DEFAULT NULL,
  `campains` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `close_account` int(2) DEFAULT NULL,
  `url` varchar(225) DEFAULT NULL,
  `bank_account` varchar(225) DEFAULT NULL,
  `bank_name` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `status`, `type`, `amount`, `image`, `campains`, `created_at`, `updated_at`, `phone`, `address`, `close_account`, `url`, `bank_account`, `bank_name`) VALUES
(1, 'Supper Admin', 'admin@gmail.com', NULL, '$2y$10$rKyxglZEFr3yJ8vXxNUhMOeT8zUgQzONBl8FvSzBVjaicvZxjT4qi', NULL, NULL, 'super-admin', 7000, NULL, '[\"1\"]', '2023-02-08 06:57:08', '2023-02-15 22:59:51', '0869946884', NULL, NULL, NULL, NULL, NULL),
(3, 'Đại lý 1', 'minhducbk88@gmail.com', NULL, '$2y$10$pgcDNchcmh1HH/Q.286EWeKn7S7gMReSgGF2whMKYOcfUfLSh8qU.', NULL, NULL, 'agency', 600100000, NULL, '[\"4\"]', '2023-02-27 01:54:31', '2023-02-27 03:59:15', '0869946881', 'HBT-HN', NULL, NULL, NULL, NULL),
(4, 'khách hàng', 'minhducbk89@gmail.com', NULL, '$2y$10$mi48MjO5bPBHHBYHGgBZleOkdLhGKqnC11/qI/tjURjxXRdFHJ0.i', NULL, NULL, 'agency', 600000000, NULL, '[\"4\"]', '2023-02-27 04:32:34', '2023-02-27 04:45:32', '0869946883', 'aaaaaaaa', NULL, NULL, NULL, NULL),
(5, 'abcxyz', 'abcxyz@gmail.com', NULL, '$2y$10$LHTNdg.Z2IvPgBY8XNpEFenNZ2phEXop1zr2hQ3ni3Jk97D3um.Ni', NULL, 0, 'agency', NULL, NULL, NULL, '2023-03-01 11:14:27', '2023-03-02 10:24:49', '8654646464', '321321', NULL, '', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campains`
--
ALTER TABLE `campains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campain_items`
--
ALTER TABLE `campain_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_news`
--
ALTER TABLE `category_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `language_pages`
--
ALTER TABLE `language_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_items`
--
ALTER TABLE `new_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `resufts`
--
ALTER TABLE `resufts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `campains`
--
ALTER TABLE `campains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `campain_items`
--
ALTER TABLE `campain_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category_news`
--
ALTER TABLE `category_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `configs`
--
ALTER TABLE `configs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `language_pages`
--
ALTER TABLE `language_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `new_items`
--
ALTER TABLE `new_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resufts`
--
ALTER TABLE `resufts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
